import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { getBooks, type Book } from "./database"

export async function getAIBookRecommendations(preferences: {
  ageGroup: string
  interests: string[]
  readingLevel?: string
  previousBooks?: string[]
}): Promise<{
  recommendations: Book[]
  explanation: string
}> {
  try {
    // Get books from database that match basic criteria
    const candidateBooks = await getBooks({
      ageGroup: preferences.ageGroup,
      limit: 50,
    })

    if (candidateBooks.length === 0) {
      return {
        recommendations: [],
        explanation: "No books found matching your criteria.",
      }
    }

    // Use AI to analyze and recommend books
    const bookSummaries = candidateBooks
      .map(
        (book) =>
          `${book.title} by ${book.author} - ${book.description?.substring(0, 100)}... (Rating: ${book.rating}, Categories: ${book.categories.join(", ")})`,
      )
      .join("\n")

    const prompt = `
    Based on these preferences:
    - Age Group: ${preferences.ageGroup}
    - Interests: ${preferences.interests.join(", ")}
    - Reading Level: ${preferences.readingLevel || "appropriate for age"}
    ${preferences.previousBooks ? `- Previously enjoyed: ${preferences.previousBooks.join(", ")}` : ""}

    From this list of available books:
    ${bookSummaries}

    Please recommend the top 6 books that would be perfect matches. Consider:
    1. Age appropriateness
    2. Interest alignment
    3. Reading level
    4. Diversity of topics
    5. High ratings and popularity

    Respond with a JSON object containing:
    - "bookTitles": array of exact book titles from the list
    - "explanation": a friendly paragraph explaining why these books were chosen

    Example format:
    {
      "bookTitles": ["Book Title 1", "Book Title 2"],
      "explanation": "These books were selected because..."
    }
    `

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
      temperature: 0.7,
    })

    const aiResponse = JSON.parse(text)

    // Filter books based on AI recommendations
    const recommendedBooks = candidateBooks.filter((book) => aiResponse.bookTitles.includes(book.title)).slice(0, 6)

    return {
      recommendations: recommendedBooks,
      explanation: aiResponse.explanation,
    }
  } catch (error) {
    console.error("Error getting AI recommendations:", error)

    // Fallback to simple algorithm
    const fallbackBooks = await getBooks({
      ageGroup: preferences.ageGroup,
      sortBy: "rating",
      limit: 6,
    })

    return {
      recommendations: fallbackBooks,
      explanation: "Here are some highly-rated books for your age group that we think you'll enjoy!",
    }
  }
}

export async function generateBookSummary(book: Book): Promise<string> {
  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `
      Create a compelling, parent-friendly summary for this children's book:
      
      Title: ${book.title}
      Author: ${book.author}
      Age Group: ${book.age_group}
      Categories: ${book.categories.join(", ")}
      Description: ${book.description || "No description available"}
      
      Write a 2-3 sentence summary that highlights:
      1. What the book is about
      2. What children will learn or enjoy
      3. Why parents/teachers would recommend it
      
      Keep it engaging and informative for parents making book choices.
      `,
      temperature: 0.7,
    })

    return text
  } catch (error) {
    console.error("Error generating book summary:", error)
    return book.description || `A wonderful ${book.age_group} book by ${book.author} that children will love.`
  }
}
