import { supabase, type Book } from "./supabase"

export async function getBooks(
  filters: {
    ageGroup?: string
    category?: string
    search?: string
    sortBy?: "popularity" | "rating" | "newest" | "title"
    limit?: number
    offset?: number
  } = {},
) {
  let query = supabase.from("books").select("*")

  // Apply filters
  if (filters.ageGroup) {
    query = query.eq("age_group", filters.ageGroup)
  }

  if (filters.category) {
    query = query.contains("categories", [filters.category])
  }

  if (filters.search) {
    query = query.or(`title.ilike.%${filters.search}%,author.ilike.%${filters.search}%`)
  }

  // Apply sorting
  switch (filters.sortBy) {
    case "popularity":
      query = query.order("popularity_score", { ascending: false })
      break
    case "rating":
      query = query.order("rating", { ascending: false })
      break
    case "newest":
      query = query.order("created_at", { ascending: false })
      break
    case "title":
      query = query.order("title", { ascending: true })
      break
    default:
      query = query.order("popularity_score", { ascending: false })
  }

  // Apply pagination
  if (filters.limit) {
    query = query.limit(filters.limit)
  }
  if (filters.offset) {
    query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1)
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching books:", error)
    return []
  }

  return data as Book[]
}

export async function getBookById(id: string) {
  const { data, error } = await supabase.from("books").select("*").eq("id", id).single()

  if (error) {
    console.error("Error fetching book:", error)
    return null
  }

  return data as Book
}

export async function getFeaturedBooks(limit = 6) {
  const { data, error } = await supabase
    .from("books")
    .select("*")
    .eq("is_featured", true)
    .order("popularity_score", { ascending: false })
    .limit(limit)

  if (error) {
    console.error("Error fetching featured books:", error)
    return []
  }

  return data as Book[]
}

export async function getTopSellerBooks(limit = 10) {
  const { data, error } = await supabase
    .from("books")
    .select("*")
    .order("popularity_score", { ascending: false })
    .limit(limit)

  if (error) {
    console.error("Error fetching top sellers:", error)
    return []
  }

  return data as Book[]
}

export async function searchBooks(
  query: string,
  filters: {
    ageGroup?: string
    categories?: string[]
    minRating?: number
    limit?: number
  } = {},
) {
  let dbQuery = supabase.from("books").select("*")

  // Full-text search
  if (query) {
    dbQuery = dbQuery.or(`title.ilike.%${query}%,author.ilike.%${query}%,description.ilike.%${query}%`)
  }

  // Apply filters
  if (filters.ageGroup) {
    dbQuery = dbQuery.eq("age_group", filters.ageGroup)
  }

  if (filters.categories && filters.categories.length > 0) {
    dbQuery = dbQuery.overlaps("categories", filters.categories)
  }

  if (filters.minRating) {
    dbQuery = dbQuery.gte("rating", filters.minRating)
  }

  // Sort by relevance (popularity for now)
  dbQuery = dbQuery.order("popularity_score", { ascending: false })

  if (filters.limit) {
    dbQuery = dbQuery.limit(filters.limit)
  }

  const { data, error } = await dbQuery

  if (error) {
    console.error("Error searching books:", error)
    return []
  }

  return data as Book[]
}
