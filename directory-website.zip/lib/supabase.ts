import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types for our database
export interface Book {
  id: string
  title: string
  author: string
  isbn?: string
  age_group: "0-3" | "4-6" | "7-9" | "10-12"
  description?: string
  image_url?: string
  rating: number
  review_count: number
  price?: number
  publisher?: string
  publish_date?: string
  page_count?: number
  categories: string[]
  awards: string[]
  amazon_url?: string
  barnes_noble_url?: string
  google_books_id?: string
  is_featured: boolean
  popularity_score: number
  created_at: string
  updated_at: string
}

export interface Review {
  id: string
  book_id: string
  user_id: string
  rating: number
  review_text?: string
  is_verified: boolean
  helpful_count: number
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  email?: string
  full_name?: string
  avatar_url?: string
  role: "user" | "educator" | "admin"
  preferences: Record<string, any>
  created_at: string
  updated_at: string
}

export interface ReadingList {
  id: string
  user_id: string
  name: string
  description?: string
  is_public: boolean
  created_at: string
  updated_at: string
}
