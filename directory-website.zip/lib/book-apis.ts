import type { Book } from "./supabase"

// Amazon Product Advertising API integration
export interface AmazonBook {
  ASIN: string
  title: string
  author: string
  price: number
  imageUrl: string
  detailPageURL: string
  rating: number
  reviewCount: number
  categories: string[]
}

// Barnes & Noble API integration
export interface BarnesNobleBook {
  isbn: string
  title: string
  author: string
  price: number
  imageUrl: string
  productUrl: string
  description: string
  ageRange: string
  categories: string[]
}

// Amazon Product Advertising API
export async function searchAmazonBooks(query: string, category = "Books", ageGroup?: string): Promise<AmazonBook[]> {
  try {
    const response = await fetch("/api/amazon/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query,
        category,
        ageGroup,
      }),
    })

    if (!response.ok) {
      throw new Error("Amazon API request failed")
    }

    const data = await response.json()
    return data.books || []
  } catch (error) {
    console.error("Error searching Amazon books:", error)
    return []
  }
}

// Barnes & Noble API
export async function searchBarnesNobleBooks(query: string, ageGroup?: string): Promise<BarnesNobleBook[]> {
  try {
    const response = await fetch("/api/barnes-noble/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        query,
        ageGroup,
      }),
    })

    if (!response.ok) {
      throw new Error("Barnes & Noble API request failed")
    }

    const data = await response.json()
    return data.books || []
  } catch (error) {
    console.error("Error searching Barnes & Noble books:", error)
    return []
  }
}

// Convert external API books to our Book format
export function convertAmazonToBook(amazonBook: AmazonBook): Partial<Book> {
  return {
    title: amazonBook.title,
    author: amazonBook.author,
    price: amazonBook.price,
    image_url: amazonBook.imageUrl,
    amazon_url: amazonBook.detailPageURL,
    rating: amazonBook.rating,
    review_count: amazonBook.reviewCount,
    categories: amazonBook.categories,
    isbn: amazonBook.ASIN, // ASIN as fallback
    description: `Available on Amazon - ${amazonBook.title} by ${amazonBook.author}`,
    age_group: determineAgeGroup(amazonBook.categories),
    status: "published",
    is_featured: false,
    awards: [],
    popularity_score: amazonBook.reviewCount * amazonBook.rating,
  }
}

export function convertBarnesNobleToBook(bnBook: BarnesNobleBook): Partial<Book> {
  return {
    title: bnBook.title,
    author: bnBook.author,
    price: bnBook.price,
    image_url: bnBook.imageUrl,
    barnes_noble_url: bnBook.productUrl,
    isbn: bnBook.isbn,
    description: bnBook.description,
    categories: bnBook.categories,
    age_group: mapAgeRange(bnBook.ageRange),
    status: "published",
    is_featured: false,
    awards: [],
    rating: 4.0, // Default rating
    review_count: 0,
    popularity_score: 100,
  }
}

// Helper functions
function determineAgeGroup(categories: string[]): string {
  const categoryStr = categories.join(" ").toLowerCase()

  if (categoryStr.includes("baby") || categoryStr.includes("toddler") || categoryStr.includes("0-3")) {
    return "0-3"
  }
  if (categoryStr.includes("preschool") || categoryStr.includes("4-6")) {
    return "4-6"
  }
  if (categoryStr.includes("early reader") || categoryStr.includes("7-9")) {
    return "7-9"
  }
  if (categoryStr.includes("middle grade") || categoryStr.includes("tween") || categoryStr.includes("10-12")) {
    return "10-12"
  }

  return "4-6" // Default
}

function mapAgeRange(ageRange: string): string {
  const age = ageRange.toLowerCase()

  if (age.includes("0-3") || age.includes("baby") || age.includes("toddler")) {
    return "0-3"
  }
  if (age.includes("4-6") || age.includes("preschool")) {
    return "4-6"
  }
  if (age.includes("7-9") || age.includes("early")) {
    return "7-9"
  }
  if (age.includes("10-12") || age.includes("middle") || age.includes("tween")) {
    return "10-12"
  }

  return "4-6" // Default
}

// Bulk import function for admin
export async function bulkImportBooks(
  source: "amazon" | "barnes-noble",
  queries: string[],
  ageGroup?: string,
): Promise<Book[]> {
  const importedBooks: Book[] = []

  for (const query of queries) {
    try {
      let externalBooks: (AmazonBook | BarnesNobleBook)[] = []

      if (source === "amazon") {
        externalBooks = await searchAmazonBooks(query, "Books", ageGroup)
      } else {
        externalBooks = await searchBarnesNobleBooks(query, ageGroup)
      }

      for (const externalBook of externalBooks) {
        const bookData =
          source === "amazon"
            ? convertAmazonToBook(externalBook as AmazonBook)
            : convertBarnesNobleToBook(externalBook as BarnesNobleBook)

        // Save to database
        const response = await fetch("/api/admin/books", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(bookData),
        })

        if (response.ok) {
          const savedBook = await response.json()
          importedBooks.push(savedBook)
        }
      }
    } catch (error) {
      console.error(`Error importing from ${source}:`, error)
    }
  }

  return importedBooks
}
