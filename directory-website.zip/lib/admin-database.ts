import { supabase } from "./supabase"
import type { Book } from "./supabase"

// Book Management Functions
export async function getAllBooks(
  filters: {
    search?: string
    status?: string
    category?: string
    ageGroup?: string
    limit?: number
    offset?: number
  } = {},
) {
  let query = supabase.from("books").select(`
      *,
      reviews:book_reviews(count),
      avg_rating:book_reviews(rating)
    `)

  // Apply filters
  if (filters.search) {
    query = query.or(`title.ilike.%${filters.search}%,author.ilike.%${filters.search}%`)
  }

  if (filters.status) {
    query = query.eq("status", filters.status)
  }

  if (filters.category) {
    query = query.contains("categories", [filters.category])
  }

  if (filters.ageGroup) {
    query = query.eq("age_group", filters.ageGroup)
  }

  // Apply pagination
  if (filters.limit) {
    query = query.limit(filters.limit)
  }
  if (filters.offset) {
    query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1)
  }

  // Order by created date (newest first)
  query = query.order("created_at", { ascending: false })

  const { data, error, count } = await query

  if (error) {
    console.error("Error fetching books:", error)
    throw new Error(`Failed to fetch books: ${error.message}`)
  }

  return { books: data as Book[], total: count || 0 }
}

export async function createBook(bookData: Partial<Book>) {
  const { data, error } = await supabase
    .from("books")
    .insert([
      {
        ...bookData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
    .select()
    .single()

  if (error) {
    console.error("Error creating book:", error)
    throw new Error(`Failed to create book: ${error.message}`)
  }

  return data as Book
}

export async function updateBook(id: string, bookData: Partial<Book>) {
  const { data, error } = await supabase
    .from("books")
    .update({
      ...bookData,
      updated_at: new Date().toISOString(),
    })
    .eq("id", id)
    .select()
    .single()

  if (error) {
    console.error("Error updating book:", error)
    throw new Error(`Failed to update book: ${error.message}`)
  }

  return data as Book
}

export async function deleteBook(id: string) {
  const { error } = await supabase.from("books").delete().eq("id", id)

  if (error) {
    console.error("Error deleting book:", error)
    throw new Error(`Failed to delete book: ${error.message}`)
  }

  return true
}

// Dashboard Statistics
export async function getDashboardStats() {
  try {
    // Get book counts by status
    const { data: bookStats, error: bookError } = await supabase.from("books").select("status")

    if (bookError) throw bookError

    // Get user counts
    const { count: totalUsers, error: userError } = await supabase
      .from("users")
      .select("*", { count: "exact", head: true })

    if (userError) throw userError

    // Get review counts and average rating
    const { data: reviewStats, error: reviewError } = await supabase.from("book_reviews").select("rating")

    if (reviewError) throw reviewError

    // Get recent activity (last 30 days)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const { count: recentBooks, error: recentError } = await supabase
      .from("books")
      .select("*", { count: "exact", head: true })
      .gte("created_at", thirtyDaysAgo.toISOString())

    if (recentError) throw recentError

    // Calculate stats
    const totalBooks = bookStats?.length || 0
    const publishedBooks = bookStats?.filter((book) => book.status === "published").length || 0
    const draftBooks = bookStats?.filter((book) => book.status === "draft").length || 0
    const featuredBooks = bookStats?.filter((book) => book.status === "published").length || 0 // Simplified

    const totalReviews = reviewStats?.length || 0
    const avgRating =
      reviewStats?.length > 0 ? reviewStats.reduce((sum, review) => sum + review.rating, 0) / reviewStats.length : 0

    return {
      totalBooks,
      publishedBooks,
      draftBooks,
      featuredBooks,
      totalUsers: totalUsers || 0,
      totalReviews,
      avgRating: Math.round(avgRating * 10) / 10,
      recentBooks: recentBooks || 0,
    }
  } catch (error) {
    console.error("Error fetching dashboard stats:", error)
    throw new Error("Failed to fetch dashboard statistics")
  }
}

// User Management Functions
export async function getAllUsers(
  filters: {
    search?: string
    role?: string
    status?: string
    limit?: number
    offset?: number
  } = {},
) {
  let query = supabase.from("users").select("*")

  // Apply filters
  if (filters.search) {
    query = query.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`)
  }

  if (filters.role) {
    query = query.eq("role", filters.role)
  }

  if (filters.status) {
    query = query.eq("status", filters.status)
  }

  // Apply pagination
  if (filters.limit) {
    query = query.limit(filters.limit)
  }
  if (filters.offset) {
    query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1)
  }

  // Order by created date (newest first)
  query = query.order("created_at", { ascending: false })

  const { data, error, count } = await query

  if (error) {
    console.error("Error fetching users:", error)
    throw new Error(`Failed to fetch users: ${error.message}`)
  }

  return { users: data, total: count || 0 }
}

export async function updateUserRole(userId: string, role: string) {
  const { data, error } = await supabase
    .from("users")
    .update({ role, updated_at: new Date().toISOString() })
    .eq("id", userId)
    .select()
    .single()

  if (error) {
    console.error("Error updating user role:", error)
    throw new Error(`Failed to update user role: ${error.message}`)
  }

  return data
}

export async function updateUserStatus(userId: string, status: string) {
  const { data, error } = await supabase
    .from("users")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", userId)
    .select()
    .single()

  if (error) {
    console.error("Error updating user status:", error)
    throw new Error(`Failed to update user status: ${error.message}`)
  }

  return data
}

// Analytics Functions
export async function getBookAnalytics(timeframe: "7d" | "30d" | "90d" = "30d") {
  const days = timeframe === "7d" ? 7 : timeframe === "30d" ? 30 : 90
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)

  try {
    // Get books created over time
    const { data: booksOverTime, error: booksError } = await supabase
      .from("books")
      .select("created_at, status")
      .gte("created_at", startDate.toISOString())
      .order("created_at", { ascending: true })

    if (booksError) throw booksError

    // Get reviews over time
    const { data: reviewsOverTime, error: reviewsError } = await supabase
      .from("book_reviews")
      .select("created_at, rating")
      .gte("created_at", startDate.toISOString())
      .order("created_at", { ascending: true })

    if (reviewsError) throw reviewsError

    // Get top categories
    const { data: allBooks, error: categoriesError } = await supabase
      .from("books")
      .select("categories")
      .eq("status", "published")

    if (categoriesError) throw categoriesError

    // Process category data
    const categoryCount: Record<string, number> = {}
    allBooks?.forEach((book) => {
      book.categories?.forEach((category: string) => {
        categoryCount[category] = (categoryCount[category] || 0) + 1
      })
    })

    const topCategories = Object.entries(categoryCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([category, count]) => ({ category, count }))

    return {
      booksOverTime: booksOverTime || [],
      reviewsOverTime: reviewsOverTime || [],
      topCategories,
    }
  } catch (error) {
    console.error("Error fetching analytics:", error)
    throw new Error("Failed to fetch analytics data")
  }
}
