/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    domains: [
      "childrensbookdirectory.com",
      "www.childrensbookdirectory.com",
      "images-na.ssl-images-amazon.com",
      "prodimage.images-bn.com",
      "placeholder.svg",
    ],
    formats: ["image/webp", "image/avif"],
    unoptimized: true,
  },
  async redirects() {
    return [
      {
        source: "/www/:path*",
        destination: "/:path*",
        permanent: true,
      },
    ]
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "X-Frame-Options",
            value: "DENY",
          },
          {
            key: "X-XSS-Protection",
            value: "1; mode=block",
          },
          {
            key: "Referrer-Policy",
            value: "origin-when-cross-origin",
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig
