import Link from "next/link"
import { Search, Filter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ListingCard } from "@/components/listing-card"
import { FilterSidebar } from "@/components/filter-sidebar"

export default function ListingsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <span className="font-bold text-xl">DirectoryHub</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/">
            Home
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/listings">
            Listings
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/categories">
            Categories
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/about">
            About
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <div className="container px-4 md:px-6 py-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/4">
              <FilterSidebar />
            </div>
            <div className="md:w-3/4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h1 className="text-3xl font-bold">All Listings</h1>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input type="search" placeholder="Search listings..." className="w-full pl-8 md:w-[300px]" />
                  </div>
                  <Button variant="outline" size="icon" className="md:hidden bg-transparent">
                    <Filter className="h-4 w-4" />
                    <span className="sr-only">Filter</span>
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <ListingCard
                  title="Coastal Cafe"
                  category="Restaurants"
                  rating={4.8}
                  reviews={124}
                  address="123 Ocean Drive"
                  image="/placeholder.svg?height=200&width=300"
                  href="/listings/coastal-cafe"
                />
                <ListingCard
                  title="Urban Fitness"
                  category="Health"
                  rating={4.6}
                  reviews={89}
                  address="456 Downtown Ave"
                  image="/placeholder.svg?height=200&width=300"
                  href="/listings/urban-fitness"
                />
                <ListingCard
                  title="Tech Solutions"
                  category="Services"
                  rating={4.9}
                  reviews={56}
                  address="789 Innovation Blvd"
                  image="/placeholder.svg?height=200&width=300"
                  href="/listings/tech-solutions"
                />
                <ListingCard
                  title="Green Gardens"
                  category="Shopping"
                  rating={4.5}
                  reviews={42}
                  address="101 Nature Lane"
                  image="/placeholder.svg?height=200&width=300"
                  href="/listings/green-gardens"
                />
                <ListingCard
                  title="City Dental"
                  category="Health"
                  rating={4.7}
                  reviews={78}
                  address="202 Medical Plaza"
                  image="/placeholder.svg?height=200&width=300"
                  href="/listings/city-dental"
                />
                <ListingCard
                  title="Sunset Restaurant"
                  category="Restaurants"
                  rating={4.4}
                  reviews={112}
                  address="303 Beachfront Ave"
                  image="/placeholder.svg?height=200&width=300"
                  href="/listings/sunset-restaurant"
                />
              </div>
              <div className="flex justify-center mt-8">
                <Button variant="outline" className="mx-1 bg-transparent">
                  1
                </Button>
                <Button variant="outline" className="mx-1 bg-transparent">
                  2
                </Button>
                <Button variant="outline" className="mx-1 bg-transparent">
                  3
                </Button>
                <Button variant="outline" className="mx-1 bg-transparent">
                  Next
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full border-t px-4 md:px-6">
        <p className="text-xs text-muted-foreground">© 2025 DirectoryHub. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
