import Link from "next/link"
import Image from "next/image"
import { Star, MapPin, Phone, Globe, Clock, ChevronLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ReviewCard } from "@/components/review-card"

export default function ListingDetailPage({ params }: { params: { slug: string } }) {
  // In a real app, you would fetch the listing data based on the slug
  const listing = {
    id: "1",
    slug: params.slug,
    title: "Coastal Cafe",
    category: "Restaurants",
    rating: 4.8,
    reviews: 124,
    address: "123 Ocean Drive, Beachside, CA 90210",
    phone: "(555) 123-4567",
    website: "https://example.com",
    hours: [
      { day: "Monday", hours: "8:00 AM - 6:00 PM" },
      { day: "Tuesday", hours: "8:00 AM - 6:00 PM" },
      { day: "Wednesday", hours: "8:00 AM - 6:00 PM" },
      { day: "Thursday", hours: "8:00 AM - 6:00 PM" },
      { day: "Friday", hours: "8:00 AM - 8:00 PM" },
      { day: "Saturday", hours: "9:00 AM - 8:00 PM" },
      { day: "Sunday", hours: "9:00 AM - 5:00 PM" },
    ],
    description:
      "A cozy cafe with ocean views, serving fresh coffee, pastries, and light meals. Perfect for a relaxing breakfast or lunch by the sea.",
    amenities: ["Free Wi-Fi", "Outdoor Seating", "Pet Friendly", "Takeout Available", "Wheelchair Accessible"],
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b">
        <Link className="flex items-center justify-center" href="/">
          <span className="font-bold text-xl">DirectoryHub</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/">
            Home
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/listings">
            Listings
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/categories">
            Categories
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="/about">
            About
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <div className="container px-4 md:px-6 py-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/listings">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Listings
            </Link>
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="relative aspect-video mb-6 overflow-hidden rounded-lg">
                <Image
                  src={listing.images[0] || "/placeholder.svg"}
                  alt={listing.title}
                  fill
                  className="object-cover"
                />
              </div>

              <div className="flex flex-wrap gap-2 mb-6">
                {listing.images.slice(1).map((image, index) => (
                  <div key={index} className="relative w-24 h-24 overflow-hidden rounded-md">
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${listing.title} ${index + 2}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>

              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h1 className="text-3xl font-bold">{listing.title}</h1>
                  <Badge>{listing.category}</Badge>
                </div>

                <div className="flex items-center mb-4">
                  <div className="flex items-center">
                    <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    <span className="ml-2 font-medium">{listing.rating}</span>
                  </div>
                  <span className="mx-2 text-muted-foreground">•</span>
                  <span className="text-muted-foreground">{listing.reviews} reviews</span>
                </div>

                <p className="text-muted-foreground mb-6">{listing.description}</p>

                <Tabs defaultValue="info">
                  <TabsList className="mb-4">
                    <TabsTrigger value="info">Information</TabsTrigger>
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                  </TabsList>
                  <TabsContent value="info">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-2">Amenities</h3>
                        <div className="flex flex-wrap gap-2">
                          {listing.amenities.map((amenity, index) => (
                            <Badge key={index} variant="outline">
                              {amenity}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium mb-2">Hours</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {listing.hours.map((item, index) => (
                            <div key={index} className="flex justify-between">
                              <span className="font-medium">{item.day}</span>
                              <span>{item.hours}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="reviews">
                    <div className="space-y-6">
                      <ReviewCard
                        name="John Doe"
                        date="2 weeks ago"
                        rating={5}
                        comment="Great place with amazing coffee and friendly staff. The ocean view is spectacular!"
                      />
                      <ReviewCard
                        name="Jane Smith"
                        date="1 month ago"
                        rating={4}
                        comment="Lovely atmosphere and good food. Gets busy on weekends though."
                      />
                      <ReviewCard
                        name="Mike Johnson"
                        date="2 months ago"
                        rating={5}
                        comment="My favorite cafe in town. Their pastries are to die for!"
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>

            <div>
              <div className="sticky top-6 space-y-6">
                <div className="bg-muted rounded-lg p-6">
                  <h3 className="text-lg font-medium mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <MapPin className="h-5 w-5 mr-2 mt-0.5 text-muted-foreground" />
                      <span>{listing.address}</span>
                    </div>
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 mr-2 text-muted-foreground" />
                      <span>{listing.phone}</span>
                    </div>
                    <div className="flex items-center">
                      <Globe className="h-5 w-5 mr-2 text-muted-foreground" />
                      <Link href={listing.website} className="text-primary hover:underline">
                        Visit Website
                      </Link>
                    </div>
                  </div>
                </div>

                <div className="bg-muted rounded-lg p-6">
                  <h3 className="text-lg font-medium mb-4">Today's Hours</h3>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-muted-foreground" />
                    <span>{listing.hours[0].hours}</span>
                  </div>
                </div>

                <Button className="w-full">Claim This Listing</Button>
                <Button variant="outline" className="w-full bg-transparent">
                  Report Listing
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full border-t px-4 md:px-6">
        <p className="text-xs text-muted-foreground">© 2025 DirectoryHub. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
