import { AIRecommendations } from "@/components/ai-recommendations"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "AI Book Recommendations | Kids Book Database",
  description:
    "Get personalized children's book recommendations powered by AI. Tell us about your child's interests and reading level for perfect book matches.",
  keywords: "AI book recommendations, personalized books, children's book suggestions, book matching",
}

export default function RecommendationsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />
      <main className="py-8">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4">
              AI-Powered Book Recommendations
            </h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Get personalized book suggestions based on your child's age, interests, and reading level
            </p>
          </div>
          <AIRecommendations />
        </div>
      </main>
      <Footer />
    </div>
  )
}
