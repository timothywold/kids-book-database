"use server"

import { supabase } from "@/lib/supabase"

export async function subscribeToNewsletter(formData: FormData) {
  const email = formData.get("email") as string
  const fullName = formData.get("fullName") as string

  if (!email) {
    return {
      success: false,
      message: "Email is required",
    }
  }

  try {
    const { data, error } = await supabase
      .from("newsletter_subscribers")
      .insert([
        {
          email,
          full_name: fullName || null,
          preferences: {},
          is_active: true,
        },
      ])
      .select()

    if (error) {
      if (error.code === "23505") {
        // Unique constraint violation
        return {
          success: false,
          message: "This email is already subscribed to our newsletter.",
        }
      }
      throw error
    }

    return {
      success: true,
      message: "Successfully subscribed to our newsletter!",
    }
  } catch (error) {
    console.error("Newsletter subscription error:", error)
    return {
      success: false,
      message: "Something went wrong. Please try again.",
    }
  }
}
