"use server"

import { searchBooks } from "@/lib/database"
import { getAIBookRecommendations } from "@/lib/ai-recommendations"

export async function performBookSearch(formData: FormData) {
  const query = formData.get("query") as string
  const ageGroup = formData.get("ageGroup") as string
  const categories = formData.getAll("categories") as string[]
  const minRating = formData.get("minRating") ? Number(formData.get("minRating")) : undefined

  try {
    const results = await searchBooks(query, {
      ageGroup: ageGroup || undefined,
      categories: categories.length > 0 ? categories : undefined,
      minRating,
      limit: 20,
    })

    return {
      success: true,
      results,
      query,
    }
  } catch (error) {
    console.error("Search error:", error)
    return {
      success: false,
      message: "Search failed. Please try again.",
      results: [],
    }
  }
}

export async function getPersonalizedRecommendations(formData: FormData) {
  const ageGroup = formData.get("ageGroup") as string
  const interests = formData.getAll("interests") as string[]
  const readingLevel = formData.get("readingLevel") as string
  const previousBooks = formData.getAll("previousBooks") as string[]

  try {
    const recommendations = await getAIBookRecommendations({
      ageGroup,
      interests,
      readingLevel: readingLevel || undefined,
      previousBooks: previousBooks.length > 0 ? previousBooks : undefined,
    })

    return {
      success: true,
      ...recommendations,
    }
  } catch (error) {
    console.error("Recommendations error:", error)
    return {
      success: false,
      message: "Failed to get recommendations. Please try again.",
      recommendations: [],
      explanation: "",
    }
  }
}
