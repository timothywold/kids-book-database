import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import { BookOpen, Heart, Users, Award } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "About the Author | BookWonders Children's Book Directory",
  description:
    "Meet the founder of BookWonders, a passionate advocate for children's literacy with over 10 years of experience in education and book curation.",
  keywords: "about author, children's book expert, literacy advocate, book curator, education specialist",
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />
      <main className="py-16">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4">About the Author</h1>
            <p className="text-xl text-gray-700">
              Passionate about connecting children with books that inspire, educate, and delight
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
            <div className="lg:col-span-1">
              <div className="relative aspect-square rounded-2xl overflow-hidden mb-6">
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Portrait of Sarah Johnson, founder of BookWonders and children's literacy advocate"
                  fill
                  className="object-cover"
                />
              </div>

              <div className="text-center space-y-4">
                <h2 className="text-2xl font-bold font-display text-gray-900">Sarah Johnson</h2>
                <p className="text-gray-600">Founder & Chief Book Curator</p>

                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="bg-warm-blue/10 rounded-lg p-4">
                    <BookOpen className="h-8 w-8 text-warm-blue mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">10+</div>
                    <div className="text-sm text-gray-600">Years Experience</div>
                  </div>
                  <div className="bg-warm-yellow/20 rounded-lg p-4">
                    <Users className="h-8 w-8 text-warm-blue mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">50K+</div>
                    <div className="text-sm text-gray-600">Families Helped</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-8">
              <div className="prose prose-lg max-w-none">
                <p className="text-gray-700 leading-relaxed">
                  Welcome to BookWonders! I'm Sarah Johnson, and I've dedicated my career to helping families discover
                  the magic of children's literature. With over a decade of experience as an elementary school librarian
                  and reading specialist, I've witnessed firsthand the transformative power of the right book in a
                  child's hands.
                </p>

                <p className="text-gray-700 leading-relaxed">
                  My journey began in a small-town library where I fell in love with the joy on children's faces when
                  they discovered a book that spoke to them. This passion led me to pursue a Master's in Library Science
                  and specialize in children's literature and early literacy development.
                </p>

                <h3 className="text-2xl font-bold font-display text-gray-900 mt-8 mb-4">My Mission</h3>
                <p className="text-gray-700 leading-relaxed">
                  BookWonders was born from a simple belief: every child deserves access to books that inspire, educate,
                  and entertain. In our digital age, I'm committed to helping parents navigate the vast world of
                  children's literature to find books that will nurture their child's love of reading.
                </p>

                <div className="bg-warm-cream/50 rounded-lg p-6 my-8">
                  <div className="flex items-center mb-4">
                    <Heart className="h-6 w-6 text-warm-blue mr-2" />
                    <h4 className="text-lg font-semibold text-gray-900">What Drives Me</h4>
                  </div>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Promoting diversity and inclusion in children's literature</li>
                    <li>• Supporting independent authors and illustrators</li>
                    <li>• Making quality books accessible to all families</li>
                    <li>• Encouraging early literacy development</li>
                  </ul>
                </div>

                <h3 className="text-2xl font-bold font-display text-gray-900 mt-8 mb-4">Credentials & Recognition</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white rounded-lg p-4 border border-gray-200">
                    <Award className="h-6 w-6 text-warm-blue mb-2" />
                    <h5 className="font-semibold text-gray-900">Education</h5>
                    <p className="text-sm text-gray-600">
                      M.L.S. in Library Science
                      <br />
                      B.A. in Elementary Education
                    </p>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-gray-200">
                    <Users className="h-6 w-6 text-warm-blue mb-2" />
                    <h5 className="font-semibold text-gray-900">Memberships</h5>
                    <p className="text-sm text-gray-600">
                      American Library Association
                      <br />
                      Children's Book Council
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
