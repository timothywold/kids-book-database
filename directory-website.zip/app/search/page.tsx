import { EnhancedSearch } from "@/components/enhanced-search"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Search Children's Books | Kids Book Database",
  description:
    "Search thousands of children's books by title, author, age group, and category. Find the perfect books with our advanced filtering system.",
  keywords: "search children's books, book finder, kids book search, book database search",
}

export default function SearchPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />
      <main className="py-8">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4">Search Our Book Database</h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto">
              Find the perfect children's books with our powerful search and filtering tools
            </p>
          </div>
          <EnhancedSearch />
        </div>
      </main>
      <Footer />
    </div>
  )
}
