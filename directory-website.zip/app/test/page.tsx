"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { getBooks, getFeaturedBooks, searchBooks } from "@/lib/database"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertCircle, Loader2 } from "lucide-react"

interface TestResult {
  name: string
  status: "pending" | "success" | "error"
  message: string
  data?: any
}

export default function TestPage() {
  const [tests, setTests] = useState<TestResult[]>([
    { name: "Database Connection", status: "pending", message: "Testing..." },
    { name: "Books Table", status: "pending", message: "Testing..." },
    { name: "Sample Data", status: "pending", message: "Testing..." },
    { name: "Search Function", status: "pending", message: "Testing..." },
    { name: "Featured Books", status: "pending", message: "Testing..." },
    { name: "Age Group Filtering", status: "pending", message: "Testing..." },
  ])

  const updateTest = (index: number, status: "success" | "error", message: string, data?: any) => {
    setTests((prev) => prev.map((test, i) => (i === index ? { ...test, status, message, data } : test)))
  }

  const runTests = async () => {
    // Reset all tests
    setTests((prev) => prev.map((test) => ({ ...test, status: "pending", message: "Testing..." })))

    try {
      // Test 1: Database Connection
      const { data: connectionTest, error: connectionError } = await supabase.from("books").select("count").limit(1)

      if (connectionError) {
        updateTest(0, "error", `Connection failed: ${connectionError.message}`)
        return
      }
      updateTest(0, "success", "Database connection successful")

      // Test 2: Books Table Structure
      const { data: tableTest, error: tableError } = await supabase
        .from("books")
        .select("id, title, author, age_group, rating")
        .limit(1)

      if (tableError) {
        updateTest(1, "error", `Table structure issue: ${tableError.message}`)
        return
      }
      updateTest(1, "success", "Books table structure is correct")

      // Test 3: Sample Data
      const sampleBooks = await getBooks({ limit: 5 })
      if (sampleBooks.length === 0) {
        updateTest(2, "error", "No sample data found. Please run the seed script.")
        return
      }
      updateTest(2, "success", `Found ${sampleBooks.length} sample books`, sampleBooks)

      // Test 4: Search Function
      const searchResults = await searchBooks("caterpillar", { limit: 3 })
      if (searchResults.length > 0) {
        updateTest(3, "success", `Search working - found ${searchResults.length} results`, searchResults)
      } else {
        updateTest(3, "error", "Search function not returning results")
      }

      // Test 5: Featured Books
      const featuredBooks = await getFeaturedBooks(3)
      if (featuredBooks.length > 0) {
        updateTest(4, "success", `Found ${featuredBooks.length} featured books`, featuredBooks)
      } else {
        updateTest(4, "error", "No featured books found")
      }

      // Test 6: Age Group Filtering
      const babyBooks = await getBooks({ ageGroup: "0-3", limit: 3 })
      if (babyBooks.length > 0) {
        updateTest(5, "success", `Age filtering working - found ${babyBooks.length} books for 0-3`, babyBooks)
      } else {
        updateTest(5, "error", "Age group filtering not working")
      }
    } catch (error) {
      console.error("Test error:", error)
      updateTest(0, "error", `Unexpected error: ${error}`)
    }
  }

  useEffect(() => {
    runTests()
  }, [])

  const getStatusIcon = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <XCircle className="h-5 w-5 text-red-500" />
      case "pending":
        return <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />
    }
  }

  const getStatusColor = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return "border-green-200 bg-green-50"
      case "error":
        return "border-red-200 bg-red-50"
      case "pending":
        return "border-blue-200 bg-blue-50"
    }
  }

  const allTestsPassed = tests.every((test) => test.status === "success")
  const hasErrors = tests.some((test) => test.status === "error")

  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white p-8">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold font-display text-gray-900 mb-4">System Test Dashboard</h1>
          <p className="text-lg text-gray-700">Testing database connectivity and core functionality</p>
        </div>

        {/* Overall Status */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {allTestsPassed ? (
                  <CheckCircle className="h-8 w-8 text-green-500" />
                ) : hasErrors ? (
                  <XCircle className="h-8 w-8 text-red-500" />
                ) : (
                  <AlertCircle className="h-8 w-8 text-yellow-500" />
                )}
                <div>
                  <h2 className="text-xl font-bold">
                    {allTestsPassed ? "All Tests Passed! 🎉" : hasErrors ? "Some Tests Failed" : "Tests Running..."}
                  </h2>
                  <p className="text-gray-600">
                    {tests.filter((t) => t.status === "success").length} of {tests.length} tests passed
                  </p>
                </div>
              </div>
              <Button onClick={runTests} className="bg-warm-blue hover:bg-warm-blue/90">
                Run Tests Again
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Individual Test Results */}
        <div className="grid gap-4">
          {tests.map((test, index) => (
            <Card key={index} className={`border-2 ${getStatusColor(test.status)}`}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center space-x-2">
                    {getStatusIcon(test.status)}
                    <span>{test.name}</span>
                  </span>
                  <Badge
                    variant={
                      test.status === "success" ? "default" : test.status === "error" ? "destructive" : "secondary"
                    }
                  >
                    {test.status}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-2">{test.message}</p>
                {test.data && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-sm font-medium text-gray-600 hover:text-gray-800">
                      View Data ({Array.isArray(test.data) ? test.data.length : 1} items)
                    </summary>
                    <pre className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-auto max-h-40">
                      {JSON.stringify(test.data, null, 2)}
                    </pre>
                  </details>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Setup Instructions */}
        {hasErrors && (
          <Card className="mt-8 border-yellow-200 bg-yellow-50">
            <CardHeader>
              <CardTitle className="flex items-center text-yellow-800">
                <AlertCircle className="h-5 w-5 mr-2" />
                Setup Required
              </CardTitle>
            </CardHeader>
            <CardContent className="text-yellow-700">
              <p className="mb-4">If tests are failing, you may need to:</p>
              <ol className="list-decimal list-inside space-y-2">
                <li>Set up your Supabase environment variables</li>
                <li>
                  Run the database setup script:{" "}
                  <code className="bg-yellow-100 px-2 py-1 rounded">scripts/setup-database.sql</code>
                </li>
                <li>
                  Run the sample data script:{" "}
                  <code className="bg-yellow-100 px-2 py-1 rounded">scripts/seed-sample-data.sql</code>
                </li>
                <li>Check your Supabase project settings and RLS policies</li>
              </ol>
            </CardContent>
          </Card>
        )}

        {/* Success Message */}
        {allTestsPassed && (
          <Card className="mt-8 border-green-200 bg-green-50">
            <CardContent className="p-6 text-center">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-green-800 mb-2">System Ready! 🚀</h3>
              <p className="text-green-700 mb-4">
                All core functionality is working. You can now test the main features:
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Button asChild className="bg-warm-blue hover:bg-warm-blue/90">
                  <a href="/directory">Browse Books</a>
                </Button>
                <Button asChild variant="outline" className="bg-transparent">
                  <a href="/search">Search Books</a>
                </Button>
                <Button asChild variant="outline" className="bg-transparent">
                  <a href="/recommendations">AI Recommendations</a>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
