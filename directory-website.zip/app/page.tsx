import Link from "next/link"
import { Database, Star, Users, Award, ChevronRight, Filter, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { BookCard } from "@/components/book-card"
import { AgeGroupCard } from "@/components/age-group-card"
import { FeaturedAuthor } from "@/components/featured-author"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { TopSellersCarousel } from "@/components/top-sellers-carousel"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative py-16 md:py-24 lg:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-warm-blue/10 to-warm-yellow/10"></div>
          <div className="container relative px-4 md:px-6">
            <div className="flex flex-col items-center text-center space-y-8">
              <div className="space-y-4 max-w-4xl">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-display text-gray-900 leading-tight">
                  Explore Thousands of Curated Children's Books
                </h1>
                <p className="text-xl md:text-2xl text-gray-700 font-serif leading-relaxed">
                  Smart filters. Honest reviews. Trusted picks for parents and teachers.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <Button
                  size="lg"
                  className="bg-warm-blue hover:bg-warm-blue/90 text-white px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce-gentle"
                  asChild
                >
                  <Link href="/directory">
                    <Database className="mr-2 h-5 w-5" />
                    Browse the Database
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-warm-blue text-warm-blue hover:bg-warm-blue hover:text-white px-8 py-4 text-lg rounded-full bg-transparent"
                  asChild
                >
                  <Link href="/about">Learn More</Link>
                </Button>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-gray-600 mt-8">
                <div className="flex items-center gap-2">
                  <Database className="h-4 w-4 text-warm-blue" />
                  <span>15,000+ Books</span>
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-warm-blue" />
                  <span>Smart Filters</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="h-4 w-4 fill-warm-yellow text-warm-yellow" />
                  <span>Honest Reviews</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-warm-blue" />
                  <span>Trusted by Educators</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="h-4 w-4 text-warm-blue" />
                  <span>Award Winners</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Search Section */}
        <section className="py-12 bg-white">
          <div className="container px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-2xl md:text-3xl font-bold font-display text-gray-900 mb-2">Find Books Instantly</h2>
                <p className="text-gray-700">Search by title, author, age, or topic</p>
              </div>

              <div className="relative max-w-2xl mx-auto">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="search"
                  placeholder="Search for books, authors, or topics..."
                  className="w-full pl-12 pr-4 py-4 text-lg border-2 border-gray-200 rounded-full focus:border-warm-blue focus:outline-none bg-gray-50 focus:bg-white transition-colors"
                />
                <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-warm-blue hover:bg-warm-blue/90 rounded-full px-6">
                  Search
                </Button>
              </div>

              <div className="flex flex-wrap justify-center gap-2 mt-6">
                <span className="text-sm text-gray-600">Popular searches:</span>
                {["Bedtime stories", "STEM books", "Picture books", "Early readers", "Award winners"].map((term) => (
                  <Button
                    key={term}
                    variant="outline"
                    size="sm"
                    className="text-xs bg-transparent border-gray-300 hover:border-warm-blue hover:text-warm-blue"
                  >
                    {term}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Top Sellers This Week */}
        <TopSellersCarousel />

        {/* Books by Age Group */}
        <section className="py-16 bg-warm-cream/30">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold font-display text-gray-900 mb-4">Browse by Age Group</h2>
              <p className="text-lg text-gray-700 max-w-2xl mx-auto">
                Find age-appropriate books that match your child's reading level and interests
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <AgeGroupCard
                ageRange="0–3"
                title="Baby & Toddler"
                description="Board books, picture books, and interactive stories"
                bookCount={2850}
                color="bg-gradient-to-br from-warm-peach to-warm-yellow"
                href="/age/0-3"
              />
              <AgeGroupCard
                ageRange="4–6"
                title="Preschool"
                description="Picture books, early learning, and bedtime stories"
                bookCount={4200}
                color="bg-gradient-to-br from-warm-blue to-blue-400"
                href="/age/4-6"
              />
              <AgeGroupCard
                ageRange="7–9"
                title="Early Readers"
                description="Chapter books, graphic novels, and adventure stories"
                bookCount={3800}
                color="bg-gradient-to-br from-warm-yellow to-yellow-400"
                href="/age/7-9"
              />
              <AgeGroupCard
                ageRange="10–12"
                title="Middle Grade"
                description="Novels, fantasy, mystery, and coming-of-age stories"
                bookCount={4150}
                color="bg-gradient-to-br from-green-400 to-emerald-500"
                href="/age/10-12"
              />
            </div>
          </div>
        </section>

        {/* Database Features */}
        <section className="py-16 bg-white">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold font-display text-gray-900 mb-4">
                Why Choose Our Database?
              </h2>
              <p className="text-lg text-gray-700 max-w-2xl mx-auto">
                Comprehensive, curated, and constantly updated with the latest children's literature
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-warm-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Filter className="h-8 w-8 text-warm-blue" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Smart Filtering</h3>
                <p className="text-gray-700">
                  Find exactly what you need with advanced filters by age, reading level, topic, awards, and more.
                </p>
              </div>

              <div className="text-center p-6">
                <div className="w-16 h-16 bg-warm-yellow/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-8 w-8 text-warm-blue" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Expert Reviews</h3>
                <p className="text-gray-700">
                  Honest, detailed reviews from educators, librarians, and reading specialists you can trust.
                </p>
              </div>

              <div className="text-center p-6">
                <div className="w-16 h-16 bg-warm-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Database className="h-8 w-8 text-warm-blue" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Always Updated</h3>
                <p className="text-gray-700">
                  Our database is constantly updated with new releases, award winners, and trending titles.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Editor's Picks */}
        <section className="py-16 bg-warm-cream/30">
          <div className="container px-4 md:px-6">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold font-display text-gray-900 mb-2">Editor's Picks</h2>
                <p className="text-lg text-gray-700">Handpicked favorites from our editorial team</p>
              </div>
              <Button variant="ghost" className="text-warm-blue hover:text-warm-blue/80" asChild>
                <Link href="/editors-picks">
                  View All <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              <BookCard
                title="The Day the Crayons Quit"
                author="Drew Daywalt"
                ageGroup="4-6"
                rating={4.8}
                price="$7.99"
                image="/placeholder.svg?height=300&width=200"
                badge="Editor's Choice"
                featured={true}
              />
              <BookCard
                title="Matilda"
                author="Roald Dahl"
                ageGroup="7-9"
                rating={4.9}
                price="$8.99"
                image="/placeholder.svg?height=300&width=200"
                badge="Timeless Classic"
                featured={true}
              />
              <BookCard
                title="The Wild Robot"
                author="Peter Brown"
                ageGroup="10-12"
                rating={4.8}
                price="$9.99"
                image="/placeholder.svg?height=300&width=200"
                badge="Must Read"
                featured={true}
              />
            </div>
          </div>
        </section>

        {/* Featured Author */}
        <FeaturedAuthor />

        {/* Newsletter Signup */}
        <section className="py-16 bg-gradient-to-r from-warm-blue to-blue-500 text-white">
          <div className="container px-4 md:px-6">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold font-display mb-4">Never Miss a Great Book</h2>
              <p className="text-xl mb-8 opacity-90">
                Get weekly recommendations, new database additions, and exclusive picks delivered to your inbox
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-3 rounded-full text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white"
                />
                <Button className="bg-warm-yellow hover:bg-warm-yellow/90 text-gray-900 font-semibold px-8 py-3 rounded-full">
                  Subscribe
                </Button>
              </div>
              <p className="text-sm mt-4 opacity-75">Join 50,000+ parents and teachers who trust our recommendations</p>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
