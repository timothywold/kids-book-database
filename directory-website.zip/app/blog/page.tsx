import { BlogLayout } from "@/components/blog-layout"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Children's Book Blog | Reading Tips & Book Reviews | BookWonders",
  description:
    "Discover the best children's books, reading tips for parents, bedtime story recommendations, and expert advice on encouraging early literacy at home.",
  keywords:
    "children's book blog, reading tips, bedtime books, early literacy, parenting advice, book reviews, indie authors, reading at home",
  openGraph: {
    title: "Children's Book Blog | Reading Tips & Reviews",
    description: "Expert advice on children's books, reading tips, and literacy development for parents and educators.",
    type: "website",
    url: "https://bookwonders.com/blog",
  },
}

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />
      <main className="py-8">
        <BlogLayout />
      </main>
      <Footer />
    </div>
  )
}
