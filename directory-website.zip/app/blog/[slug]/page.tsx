import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Calendar, Clock, User, Tag, ArrowLeft, Share2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import type { Metadata } from "next"

// This would typically come from a database or CMS
const getBlogPost = (slug: string) => {
  const posts = {
    "10-bedtime-books-kids-love-2025": {
      title: "10 Bedtime Books Kids Love in 2025",
      excerpt:
        "Discover the most beloved bedtime stories that help children wind down and develop healthy sleep routines.",
      content: `
        <p>Creating a peaceful bedtime routine is essential for children's development, and the right books can make all the difference. Here are the top 10 bedtime books that kids absolutely love in 2025.</p>
        
        <h2>Why Bedtime Books Matter</h2>
        <p>Bedtime stories serve multiple purposes beyond entertainment. They help children wind down, process their day, and develop important language skills. Research shows that children who are read to regularly develop stronger vocabulary and reading comprehension skills.</p>
        
        <h2>Our Top 10 Picks</h2>
        <h3>1. Goodnight Moon by Margaret Wise Brown</h3>
        <p>This timeless classic continues to be a favorite among parents and children alike. The soothing rhythm and familiar routine help signal to children that it's time to sleep.</p>
        
        <h3>2. The Going to Bed Book by Sandra Boynton</h3>
        <p>Perfect for toddlers, this book follows animals as they get ready for bed, making it relatable and fun for young children.</p>
        
        <p><em>Continue reading for the complete list of bedtime favorites...</em></p>
      `,
      author: "Sarah Johnson",
      publishDate: "2025-01-08",
      readTime: "5 min read",
      featuredImage: "/placeholder.svg?height=400&width=800",
      tags: ["bedtime books", "sleep routines", "picture books"],
      category: "Book Lists",
    },
  }

  return posts[slug as keyof typeof posts] || null
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = getBlogPost(params.slug)

  if (!post) {
    return {
      title: "Post Not Found | BookWonders Blog",
    }
  }

  return {
    title: `${post.title} | BookWonders Blog`,
    description: post.excerpt,
    keywords: post.tags.join(", "),
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: "article",
      publishedTime: post.publishDate,
      authors: [post.author],
      images: [post.featuredImage],
    },
  }
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = getBlogPost(params.slug)

  if (!post) {
    notFound()
  }

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    author: {
      "@type": "Person",
      name: post.author,
    },
    datePublished: post.publishDate,
    image: post.featuredImage,
    keywords: post.tags.join(", "),
    publisher: {
      "@type": "Organization",
      name: "BookWonders",
    },
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      <main className="py-8">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto">
          <Button variant="ghost" className="mb-6" asChild>
            <Link href="/blog">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Blog
            </Link>
          </Button>

          <article>
            <header className="mb-8">
              <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500 mb-4">
                <Badge variant="outline" className="bg-warm-cream">
                  {post.category}
                </Badge>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>{new Date(post.publishDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="h-3 w-3" />
                  <span>{post.readTime}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <User className="h-3 w-3" />
                  <span>by {post.author}</span>
                </div>
              </div>

              <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4 leading-tight">
                {post.title}
              </h1>

              <p className="text-xl text-gray-700 leading-relaxed mb-6">{post.excerpt}</p>

              <div className="flex flex-wrap gap-2 mb-6">
                {post.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="bg-gray-50 text-gray-600">
                    <Tag className="h-3 w-3 mr-1" />
                    {tag}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Button className="bg-warm-blue hover:bg-warm-blue/90">
                    <Share2 className="h-4 w-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>
            </header>

            <div className="relative aspect-video mb-8 overflow-hidden rounded-lg">
              <Image
                src={post.featuredImage || "/placeholder.svg"}
                alt={`Featured image for ${post.title} - A comprehensive guide to bedtime books for children`}
                fill
                className="object-cover"
                priority
              />
            </div>

            <div
              className="prose prose-lg max-w-none prose-headings:font-display prose-headings:text-gray-900 prose-p:text-gray-700 prose-p:leading-relaxed"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </article>
        </div>
      </main>

      <Footer />
    </div>
  )
}
