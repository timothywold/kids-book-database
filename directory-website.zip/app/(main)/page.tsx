import type { Metadata } from "next"
import { BookDirectory } from "@/components/book-directory"
import { TopSellersCarousel } from "@/components/top-sellers-carousel"
import { FeaturedAuthor } from "@/components/featured-author"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, BookOpen, Award, Search, Filter } from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Children's Book Directory - Discover Amazing Children's Books",
  description:
    "The ultimate directory for children's books. Find age-appropriate books, read reviews, and discover your child's next favorite story.",
  keywords: "children's books, kids books, picture books, chapter books, educational books, reading",
  openGraph: {
    title: "Children's Book Directory - Discover Amazing Children's Books",
    description:
      "The ultimate directory for children's books. Find age-appropriate books, read reviews, and discover your child's next favorite story.",
    url: "https://childrensbookdirectory.com",
    siteName: "Children's Book Directory",
    images: [
      {
        url: "https://childrensbookdirectory.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Children's Book Directory - Children's Book Directory",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  alternates: {
    canonical: "https://childrensbookdirectory.com",
  },
}

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <Badge variant="secondary" className="mb-4 bg-orange-100 text-orange-800">
            Trusted by 50,000+ Parents & Teachers
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Discover Amazing <span className="text-orange-600">Children's Books</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            The ultimate directory for children's books. Find age-appropriate books, read honest reviews, and discover
            your child's next favorite story.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-orange-600 hover:bg-orange-700">
              <Link href="/directory">
                <BookOpen className="mr-2 h-5 w-5" />
                Browse Books
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/search">
                <Search className="mr-2 h-5 w-5" />
                Smart Search
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-orange-600 mb-2">25,000+</div>
              <div className="text-gray-600">Curated Books</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-600 mb-2">50,000+</div>
              <div className="text-gray-600">Happy Families</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-600 mb-2">15,000+</div>
              <div className="text-gray-600">Honest Reviews</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-orange-600 mb-2">500+</div>
              <div className="text-gray-600">Award Winners</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Parents & Teachers Love Us</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Smart filters, honest reviews, and trusted recommendations make finding the perfect book effortless.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Filter className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Smart Filters</h3>
                <p className="text-gray-600">
                  Find books by age, reading level, topic, and theme. Our advanced filters make discovery easy.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Star className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Honest Reviews</h3>
                <p className="text-gray-600">
                  Real reviews from parents, teachers, and librarians help you make informed choices.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Award className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Trusted Picks</h3>
                <p className="text-gray-600">
                  Curated selections from award-winning books and educational experts you can trust.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Top Sellers Carousel */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Trending This Week</h2>
            <p className="text-xl text-gray-600">Discover what other families are reading right now</p>
          </div>
          <TopSellersCarousel />
        </div>
      </section>

      {/* Featured Author */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <FeaturedAuthor />
        </div>
      </section>

      {/* Book Directory Preview */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Explore Our Directory</h2>
            <p className="text-xl text-gray-600 mb-8">Browse books by age group, category, or discover something new</p>
          </div>
          <BookDirectory />
          <div className="text-center mt-8">
            <Button asChild size="lg" variant="outline">
              <Link href="/directory">View Full Directory</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-orange-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Find Your Child's Next Favorite Book?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of parents and teachers who trust our recommendations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/directory">Start Exploring</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-orange-600 bg-transparent"
            >
              <Link href="/recommendations">Get Recommendations</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
