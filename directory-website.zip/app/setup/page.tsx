import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Database, Key, Upload, Zap } from "lucide-react"

export default function SetupPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white p-8">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold font-display text-gray-900 mb-4">Setup Guide</h1>
          <p className="text-lg text-gray-700">Get your Kids Book Database up and running</p>
        </div>

        <div className="space-y-6">
          {/* Step 1: Environment Variables */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Key className="h-5 w-5 mr-2 text-warm-blue" />
                Step 1: Environment Variables
                <Badge className="ml-2 bg-red-100 text-red-800">Required</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                Create a <code className="bg-gray-100 px-2 py-1 rounded">.env.local</code> file in your project root
                with:
              </p>
              <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm">
                {`# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# OpenAI for AI Recommendations (Optional)
OPENAI_API_KEY=your_openai_api_key`}
              </pre>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm">
                  <strong>Where to find these:</strong>
                  <br />
                  1. Go to your Supabase project dashboard
                  <br />
                  2. Navigate to Settings → API
                  <br />
                  3. Copy the Project URL and anon/service_role keys
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Step 2: Database Setup */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="h-5 w-5 mr-2 text-warm-blue" />
                Step 2: Database Setup
                <Badge className="ml-2 bg-red-100 text-red-800">Required</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">Run the database setup script in your Supabase SQL editor:</p>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800 text-sm font-medium mb-2">📝 Instructions:</p>
                <ol className="text-yellow-700 text-sm space-y-1 list-decimal list-inside">
                  <li>Go to your Supabase project dashboard</li>
                  <li>Navigate to SQL Editor</li>
                  <li>Create a new query</li>
                  <li>
                    Copy and paste the contents of <code>scripts/setup-database.sql</code>
                  </li>
                  <li>Click "Run" to execute</li>
                </ol>
              </div>

              <details className="border border-gray-200 rounded-lg">
                <summary className="p-4 cursor-pointer font-medium text-gray-700 hover:bg-gray-50">
                  View Database Schema Preview
                </summary>
                <div className="p-4 border-t bg-gray-50">
                  <pre className="text-xs text-gray-600 overflow-x-auto">
                    {`Tables Created:
├── books (main book data)
├── reviews (user reviews)
├── profiles (user profiles)
├── reading_lists (user book lists)
├── reading_list_items (list contents)
└── newsletter_subscribers (email list)

Features Enabled:
├── Row Level Security (RLS)
├── Full-text search indexes
├── Performance optimizations
└── User authentication policies`}
                  </pre>
                </div>
              </details>
            </CardContent>
          </Card>

          {/* Step 3: Sample Data */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="h-5 w-5 mr-2 text-warm-blue" />
                Step 3: Sample Data
                <Badge className="ml-2 bg-yellow-100 text-yellow-800">Recommended</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">Add sample books to test the functionality:</p>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 text-sm font-medium mb-2">📚 Sample Data Includes:</p>
                <ul className="text-green-700 text-sm space-y-1 list-disc list-inside">
                  <li>8 popular children's books across all age groups</li>
                  <li>Complete metadata (ratings, categories, awards)</li>
                  <li>Amazon and Barnes & Noble links</li>
                  <li>Featured book flags for testing</li>
                </ul>
              </div>

              <p className="text-sm text-gray-600">
                Run <code className="bg-gray-100 px-2 py-1 rounded">scripts/seed-sample-data.sql</code> in the same way
                as Step 2.
              </p>
            </CardContent>
          </Card>

          {/* Step 4: Test Everything */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2 text-warm-blue" />
                Step 4: Test Your Setup
                <Badge className="ml-2 bg-green-100 text-green-800">Verify</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">Use our built-in test dashboard to verify everything works:</p>

              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="/test"
                  className="inline-flex items-center justify-center px-6 py-3 bg-warm-blue text-white font-semibold rounded-lg hover:bg-warm-blue/90 transition-colors"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Run System Tests
                </a>
                <a
                  href="/directory"
                  className="inline-flex items-center justify-center px-6 py-3 border border-warm-blue text-warm-blue font-semibold rounded-lg hover:bg-warm-blue hover:text-white transition-colors"
                >
                  Browse Books
                </a>
              </div>

              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <p className="text-gray-700 text-sm font-medium mb-2">✅ What the tests check:</p>
                <ul className="text-gray-600 text-sm space-y-1 list-disc list-inside">
                  <li>Database connection and authentication</li>
                  <li>Table structure and data integrity</li>
                  <li>Search functionality</li>
                  <li>Age group filtering</li>
                  <li>Featured books system</li>
                  <li>AI recommendations (if OpenAI key provided)</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Optional Features */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2 text-gray-400" />
                Optional: AI Features
                <Badge className="ml-2 bg-gray-100 text-gray-600">Optional</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">
                For AI-powered book recommendations, add your OpenAI API key to the environment variables.
              </p>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm">
                  <strong>Without OpenAI:</strong> The system will fall back to algorithm-based recommendations using
                  ratings and popularity.
                  <br />
                  <strong>With OpenAI:</strong> Get personalized, intelligent book suggestions based on interests and
                  reading level.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Start */}
        <Card className="mt-8 border-2 border-warm-blue bg-warm-blue/5">
          <CardHeader>
            <CardTitle className="text-warm-blue">🚀 Quick Start Checklist</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm">Environment variables set</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm">Database schema created</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm">Sample data loaded</span>
                </label>
              </div>
              <div className="space-y-2">
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm">System tests passed</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm">Book directory working</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" className="rounded" />
                  <span className="text-sm">Search functionality tested</span>
                </label>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
