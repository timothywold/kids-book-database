import { EnhancedBookDirectory } from "@/components/enhanced-book-directory"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Children's Book Directory | Browse by Age Group | BookWonders",
  description:
    "Discover the perfect children's books by age group. Browse bedtime stories, STEM books, early readers, and award-winning titles for babies, toddlers, preschoolers, and tweens.",
  keywords:
    "children's books, bedtime books, STEM stories, early readers, picture books, board books, chapter books, award-winning books, educational books",
}

export default function DirectoryPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-warm-cream to-white">
      <Header />
      <main className="py-8">
        <EnhancedBookDirectory />
      </main>
      <Footer />
    </div>
  )
}
