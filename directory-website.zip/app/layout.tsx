import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/lib/auth-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Children's Book Directory | Discover the Best Children's Books by Age, Topic & Theme",
  description:
    "Explore thousands of curated children's books with smart filters, honest reviews, and trusted picks for parents and teachers. Find the perfect books for every child.",
  keywords:
    "children's books, kids books, picture books, early readers, middle grade, book directory, book recommendations, age-appropriate books, educational books",
  authors: [{ name: "Children's Book Directory Team" }],
  metadataBase: new URL("https://childrensbookdirectory.com"),
  openGraph: {
    title: "Children's Book Directory - Discover the Best Children's Books",
    description: "Smart filters. Honest reviews. Trusted picks for parents and teachers.",
    url: "https://childrensbookdirectory.com",
    siteName: "Children's Book Directory",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Children's Book Directory - Children's Book Directory",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Children's Book Directory - Discover the Best Children's Books",
    description: "Smart filters. Honest reviews. Trusted picks for parents and teachers.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "https://childrensbookdirectory.com",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <AuthProvider>{children}</AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
