import { AdminLogin } from "@/components/admin/admin-login"

export default function AdminLoginPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <AdminLogin />
    </div>
  )
}
