import { AdminLayout } from "@/components/admin/admin-layout"
import { BookImport } from "@/components/admin/book-import"

export default function BookImportPage() {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Import Books</h1>
          <p className="text-gray-600">Bulk import books from Amazon and Barnes & Noble</p>
        </div>

        <BookImport />
      </div>
    </AdminLayout>
  )
}
