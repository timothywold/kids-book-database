import { AdminHeader } from "@/components/admin/admin-header"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { BookForm } from "@/components/admin/book-form"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Add Book | Admin Dashboard",
  description: "Add a new book to the Kids Book Database",
}

export default function AddBookPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-6">
          <BookForm />
        </main>
      </div>
    </div>
  )
}
