import { AdminLayout } from "@/components/admin/admin-layout"
import { BooksManagement } from "@/components/admin/books-management"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Books Management | Admin Dashboard",
  description: "Manage books in the Kids Book Database",
}

export default function AdminBooksPage() {
  return (
    <AdminLayout>
      <BooksManagement />
    </AdminLayout>
  )
}
