import { type NextRequest, NextResponse } from "next/server"
import { updateBook, deleteBook } from "@/lib/admin-database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const bookData = await request.json()
    const updatedBook = await updateBook(params.id, bookData)
    return NextResponse.json(updatedBook)
  } catch (error) {
    console.error("Update book API error:", error)
    return NextResponse.json({ error: "Failed to update book" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await deleteBook(params.id)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete book API error:", error)
    return NextResponse.json({ error: "Failed to delete book" }, { status: 500 })
  }
}
