import { NextResponse } from "next/server"
import { getDashboardStats, getBookAnalytics } from "@/lib/admin-database"

export async function GET() {
  try {
    const [stats, analytics] = await Promise.all([getDashboardStats(), getBookAnalytics("30d")])

    return NextResponse.json({
      stats,
      analytics,
    })
  } catch (error) {
    console.error("Dashboard API error:", error)
    return NextResponse.json({ error: "Failed to fetch dashboard data" }, { status: 500 })
  }
}
