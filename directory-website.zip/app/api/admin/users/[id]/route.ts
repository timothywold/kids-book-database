import { type NextRequest, NextResponse } from "next/server"
import { updateUserRole, updateUserStatus } from "@/lib/admin-database"

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { action, value } = await request.json()

    let result
    if (action === "role") {
      result = await updateUserRole(params.id, value)
    } else if (action === "status") {
      result = await updateUserStatus(params.id, value)
    } else {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Update user API error:", error)
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}
