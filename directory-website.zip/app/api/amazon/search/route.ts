import { type NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

// Amazon Product Advertising API configuration
const AMAZON_ACCESS_KEY = process.env.AMAZON_ACCESS_KEY_ID
const AMAZON_SECRET_KEY = process.env.AMAZON_SECRET_ACCESS_KEY
const AMAZON_ASSOCIATE_TAG = process.env.AMAZON_ASSOCIATE_TAG
const AMAZON_REGION = "us-east-1"
const AMAZON_HOST = "webservices.amazon.com"

// AWS Signature Version 4 signing
function createSignature(stringToSign: string, secretKey: string): string {
  return crypto.createHmac("sha256", secretKey).update(stringToSign).digest("base64")
}

function createAmazonRequest(params: Record<string, string>) {
  const timestamp = new Date().toISOString()

  const defaultParams = {
    Service: "AWSECommerceService",
    Operation: "ItemSearch",
    AWSAccessKeyId: AMAZON_ACCESS_KEY!,
    AssociateTag: AMAZON_ASSOCIATE_TAG!,
    Timestamp: timestamp,
    Version: "2013-08-01",
    SignatureVersion: "2",
    SignatureMethod: "HmacSHA256",
  }

  const allParams = { ...defaultParams, ...params }

  // Sort parameters
  const sortedParams = Object.keys(allParams)
    .sort()
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(allParams[key])}`)
    .join("&")

  const stringToSign = `GET\n${AMAZON_HOST}\n/onca/xml\n${sortedParams}`
  const signature = createSignature(stringToSign, AMAZON_SECRET_KEY!)

  return `https://${AMAZON_HOST}/onca/xml?${sortedParams}&Signature=${encodeURIComponent(signature)}`
}

export async function POST(request: NextRequest) {
  try {
    const { query, category = "Books", ageGroup } = await request.json()

    if (!AMAZON_ACCESS_KEY || !AMAZON_SECRET_KEY || !AMAZON_ASSOCIATE_TAG) {
      return NextResponse.json({ error: "Amazon API credentials not configured" }, { status: 500 })
    }

    // Build search parameters
    const searchParams: Record<string, string> = {
      SearchIndex: category,
      Keywords: query,
      ResponseGroup: "Images,ItemAttributes,Offers,Reviews",
      ItemPage: "1",
    }

    // Add age-specific search refinements
    if (ageGroup) {
      const ageRefinements = {
        "0-3": "baby toddler board book",
        "4-6": "preschool picture book",
        "7-9": "early reader chapter book",
        "10-12": "middle grade tween",
      }

      searchParams.Keywords = `${query} ${ageRefinements[ageGroup as keyof typeof ageRefinements] || ""}`
    }

    const amazonUrl = createAmazonRequest(searchParams)

    const response = await fetch(amazonUrl, {
      headers: {
        "User-Agent": "Kids Book Database/1.0",
      },
    })

    if (!response.ok) {
      throw new Error(`Amazon API error: ${response.status}`)
    }

    const xmlData = await response.text()

    // Parse XML response (you'll need to install xml2js: npm install xml2js @types/xml2js)
    const xml2js = require("xml2js")
    const parser = new xml2js.Parser()
    const result = await parser.parseStringPromise(xmlData)

    const items = result?.ItemSearchResponse?.Items?.[0]?.Item || []

    const books = items.map((item: any) => ({
      ASIN: item.ASIN?.[0],
      title: item.ItemAttributes?.[0]?.Title?.[0] || "Unknown Title",
      author: item.ItemAttributes?.[0]?.Author?.[0] || "Unknown Author",
      price: Number.parseFloat(item.OfferSummary?.[0]?.LowestNewPrice?.[0]?.Amount?.[0] || "0") / 100,
      imageUrl: item.LargeImage?.[0]?.URL?.[0] || item.MediumImage?.[0]?.URL?.[0] || "",
      detailPageURL: item.DetailPageURL?.[0] || "",
      rating: Number.parseFloat(item.CustomerReviews?.[0]?.AverageRating?.[0] || "4.0"),
      reviewCount: Number.parseInt(item.CustomerReviews?.[0]?.TotalReviews?.[0] || "0"),
      categories: item.ItemAttributes?.[0]?.ProductGroup || ["Books"],
    }))

    return NextResponse.json({ books })
  } catch (error) {
    console.error("Amazon API error:", error)
    return NextResponse.json({ error: "Failed to search Amazon books" }, { status: 500 })
  }
}
