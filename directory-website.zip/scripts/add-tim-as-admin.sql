-- Run this script AFTER wold.tim2@gmail.com has signed up through Supabase Auth
-- This will add them to the admin_users table with super_admin role

-- Add wold.tim2@gmail.com as super admin
SELECT add_admin_user('wold.tim2@gmail.com', 'super_admin');

-- Verify the admin user was added
SELECT 
  au.email,
  au.role,
  au.created_at,
  u.email_confirmed_at
FROM admin_users au
JOIN auth.users u ON au.id = u.id
WHERE au.email = 'wold.tim2@gmail.com';
