-- Create books table
CREATE TABLE books (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  isbn TEXT UNIQUE,
  age_group TEXT NOT NULL CHECK (age_group IN ('0-3', '4-6', '7-9', '10-12')),
  description TEXT,
  image_url TEXT,
  rating DECIMAL(2,1) DEFAULT 0,
  review_count INTEGER DEFAULT 0,
  price DECIMAL(10,2),
  publisher TEXT,
  publish_date DATE,
  page_count INTEGER,
  categories TEXT[] DEFAULT '{}',
  awards TEXT[] DEFAULT '{}',
  amazon_url TEXT,
  barnes_noble_url TEXT,
  google_books_id TEXT,
  is_featured BOOLEAN DEFAULT FALSE,
  popularity_score INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create reviews table
CREATE TABLE reviews (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  helpful_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(book_id, user_id)
);

-- Create user profiles table
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT,
  full_name TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'educator', 'admin')),
  preferences JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create reading lists table
CREATE TABLE reading_lists (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  is_public BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create reading list items table
CREATE TABLE reading_list_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  list_id UUID REFERENCES reading_lists(id) ON DELETE CASCADE,
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  added_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(list_id, book_id)
);

-- Create newsletter subscribers table
CREATE TABLE newsletter_subscribers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  preferences JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT TRUE,
  subscribed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  unsubscribed_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for better performance
CREATE INDEX idx_books_age_group ON books(age_group);
CREATE INDEX idx_books_rating ON books(rating DESC);
CREATE INDEX idx_books_popularity ON books(popularity_score DESC);
CREATE INDEX idx_books_categories ON books USING GIN(categories);
CREATE INDEX idx_books_title_search ON books USING GIN(to_tsvector('english', title));
CREATE INDEX idx_books_author_search ON books USING GIN(to_tsvector('english', author));
CREATE INDEX idx_reviews_book_id ON reviews(book_id);
CREATE INDEX idx_reviews_user_id ON reviews(user_id);

-- Enable Row Level Security
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE reading_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE reading_list_items ENABLE ROW LEVEL SECURITY;

-- Create policies
-- Books are readable by everyone, writable by admins
CREATE POLICY "Books are viewable by everyone" ON books FOR SELECT USING (true);
CREATE POLICY "Books are insertable by admins" ON books FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);
CREATE POLICY "Books are updatable by admins" ON books FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);

-- Reviews are readable by everyone, writable by authenticated users
CREATE POLICY "Reviews are viewable by everyone" ON reviews FOR SELECT USING (true);
CREATE POLICY "Reviews are insertable by authenticated users" ON reviews FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Reviews are updatable by owner" ON reviews FOR UPDATE USING (auth.uid() = user_id);

-- Profiles are readable by owner, writable by owner
CREATE POLICY "Profiles are viewable by owner" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Profiles are insertable by owner" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Profiles are updatable by owner" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Reading lists policies
CREATE POLICY "Reading lists are viewable by owner or if public" ON reading_lists FOR SELECT USING (
  auth.uid() = user_id OR is_public = true
);
CREATE POLICY "Reading lists are insertable by authenticated users" ON reading_lists FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Reading lists are updatable by owner" ON reading_lists FOR UPDATE USING (auth.uid() = user_id);

-- Reading list items policies
CREATE POLICY "Reading list items are viewable by list owner or if list is public" ON reading_list_items FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM reading_lists 
    WHERE reading_lists.id = reading_list_items.list_id 
    AND (reading_lists.user_id = auth.uid() OR reading_lists.is_public = true)
  )
);
CREATE POLICY "Reading list items are insertable by list owner" ON reading_list_items FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM reading_lists 
    WHERE reading_lists.id = reading_list_items.list_id 
    AND reading_lists.user_id = auth.uid()
  )
);
