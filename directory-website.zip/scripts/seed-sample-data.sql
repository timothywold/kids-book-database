-- Insert sample books
INSERT INTO books (title, author, age_group, description, rating, review_count, price, categories, awards, is_featured, popularity_score, image_url, amazon_url, barnes_noble_url) VALUES
('The Very Hungry Caterpillar', 'Eric Carle', '0-3', 'A classic tale of a caterpillar''s transformation into a beautiful butterfly, teaching counting and days of the week.', 4.9, 15420, 8.99, ARRAY['classic', 'educational', 'picture book'], ARRAY['American Institute of Graphic Arts Award'], true, 98, '/placeholder.svg?height=300&width=200', 'https://amazon.com/very-hungry-caterpillar', 'https://barnesandnoble.com/very-hungry-caterpillar'),

('Goodnight Moon', 'Margaret Wise Brown', '0-3', 'The ultimate bedtime book that has soothed children to sleep for generations with its gentle rhythm and calming illustrations.', 4.8, 18750, 8.99, ARRAY['bedtime', 'classic', 'picture book'], ARRAY[], true, 95, '/placeholder.svg?height=300&width=200', 'https://amazon.com/goodnight-moon', 'https://barnesandnoble.com/goodnight-moon'),

('The Day the Crayons Quit', 'Drew Daywalt', '4-6', 'A hilarious story told through letters from crayons who have had enough, teaching colors and creativity.', 4.8, 11240, 7.99, ARRAY['humor', 'creativity', 'picture book'], ARRAY['Goodreads Choice Award'], true, 92, '/placeholder.svg?height=300&width=200', 'https://amazon.com/day-crayons-quit', 'https://barnesandnoble.com/day-crayons-quit'),

('Where the Wild Things Are', 'Maurice Sendak', '4-6', 'Max''s imaginative journey to the land of the Wild Things, exploring themes of imagination and emotion.', 4.8, 12350, 9.99, ARRAY['classic', 'imagination', 'picture book'], ARRAY['Caldecott Medal'], true, 94, '/placeholder.svg?height=300&width=200', 'https://amazon.com/where-wild-things-are', 'https://barnesandnoble.com/where-wild-things-are'),

('Dog Man: Mothering Heights', 'Dav Pilkey', '7-9', 'The latest adventure in the beloved graphic novel series that combines humor with important lessons about family and friendship.', 4.7, 8920, 5.99, ARRAY['graphic novel', 'humor', 'series'], ARRAY[], true, 94, '/placeholder.svg?height=300&width=200', 'https://amazon.com/dog-man-mothering-heights', 'https://barnesandnoble.com/dog-man-mothering-heights'),

('Wonder', 'R.J. Palacio', '10-12', 'A powerful story about kindness, acceptance, and the importance of being yourself, perfect for teaching empathy.', 4.9, 25680, 8.99, ARRAY['realistic fiction', 'empathy', 'school'], ARRAY['Dorothy Canfield Fisher Children''s Book Award'], true, 97, '/placeholder.svg?height=300&width=200', 'https://amazon.com/wonder-rj-palacio', 'https://barnesandnoble.com/wonder'),

('The Wild Robot', 'Peter Brown', '10-12', 'An award-winning story combining robotics with nature themes, exploring technology, survival, and belonging.', 4.8, 8940, 9.99, ARRAY['STEM', 'adventure', 'robots'], ARRAY['E.B. White Read-Aloud Award'], true, 88, '/placeholder.svg?height=300&width=200', 'https://amazon.com/wild-robot', 'https://barnesandnoble.com/wild-robot'),

('Ada Twist, Scientist', 'Andrea Beaty', '4-6', 'Inspiring STEM story featuring a curious young scientist, encouraging scientific thinking and experimentation.', 4.7, 6840, 9.99, ARRAY['STEM', 'empowerment', 'picture book'], ARRAY['Parents'' Choice Gold Award'], true, 89, '/placeholder.svg?height=300&width=200', 'https://amazon.com/ada-twist-scientist', 'https://barnesandnoble.com/ada-twist-scientist');

-- Update the books count statistics
UPDATE books SET popularity_score = popularity_score + (rating * 10) + (review_count / 100);
