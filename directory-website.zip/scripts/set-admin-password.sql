-- Update the password for wold.tim2@gmail.com to $pl1tR0ck!00
-- This script assumes the user already exists in auth.users

UPDATE auth.users 
SET 
  encrypted_password = crypt('$pl1tR0ck!00', gen_salt('bf')),
  updated_at = NOW()
WHERE email = 'wold.tim2@gmail.com';

-- Verify the user exists and password was updated
SELECT 
  email,
  created_at,
  updated_at,
  email_confirmed_at
FROM auth.users 
WHERE email = 'wold.tim2@gmail.com';

-- Ensure user is in admin_users table
INSERT INTO admin_users (id, email, role)
SELECT id, email, 'super_admin'
FROM auth.users 
WHERE email = 'wold.tim2@gmail.com'
ON CONFLICT (email) DO UPDATE SET
  role = 'super_admin',
  updated_at = NOW();

-- Verify admin status
SELECT 
  au.email,
  au.role,
  au.created_at as admin_since
FROM admin_users au
WHERE au.email = 'wold.tim2@gmail.com';
