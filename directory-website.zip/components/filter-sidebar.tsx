import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"

export function FilterSidebar() {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Categories</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox id="restaurants" />
            <label
              htmlFor="restaurants"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Restaurants
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="shopping" />
            <label
              htmlFor="shopping"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Shopping
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="health" />
            <label
              htmlFor="health"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Health
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="services" />
            <label
              htmlFor="services"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Services
            </label>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4">Rating</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox id="rating-5" />
            <label
              htmlFor="rating-5"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              5 Stars
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="rating-4" />
            <label
              htmlFor="rating-4"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              4+ Stars
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="rating-3" />
            <label
              htmlFor="rating-3"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              3+ Stars
            </label>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4">Distance</h3>
        <Slider defaultValue={[5]} max={50} step={1} className="mb-2" />
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>0 mi</span>
          <span>50 mi</span>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4">Features</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox id="open-now" />
            <label
              htmlFor="open-now"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Open Now
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="free-wifi" />
            <label
              htmlFor="free-wifi"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Free Wi-Fi
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="parking" />
            <label
              htmlFor="parking"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Parking Available
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="pet-friendly" />
            <label
              htmlFor="pet-friendly"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Pet Friendly
            </label>
          </div>
        </div>
      </div>

      <Button className="w-full">Apply Filters</Button>
      <Button variant="outline" className="w-full bg-transparent">
        Reset
      </Button>
    </div>
  )
}
