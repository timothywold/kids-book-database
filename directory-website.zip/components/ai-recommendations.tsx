"use client"

import { useState, useTransition } from "react"
import { Sparkles, Loader2, RefreshCw } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getPersonalizedRecommendations } from "@/app/actions/search"
import type { Book } from "@/lib/database"
import { DatabaseBookCard } from "./enhanced-book-directory"

const interests = [
  "Animals",
  "Adventure",
  "Science",
  "Art",
  "Music",
  "Sports",
  "Friendship",
  "Family",
  "School",
  "Fantasy",
  "Mystery",
  "Humor",
  "History",
  "Nature",
  "Space",
  "Dinosaurs",
  "Princesses",
  "Superheroes",
]

const readingLevels = [
  { value: "beginner", label: "Beginner Reader" },
  { value: "developing", label: "Developing Reader" },
  { value: "fluent", label: "Fluent Reader" },
  { value: "advanced", label: "Advanced Reader" },
]

export function AIRecommendations() {
  const [selectedAgeGroup, setSelectedAgeGroup] = useState("")
  const [selectedInterests, setSelectedInterests] = useState<string[]>([])
  const [readingLevel, setReadingLevel] = useState("")
  const [recommendations, setRecommendations] = useState<Book[]>([])
  const [explanation, setExplanation] = useState("")
  const [isPending, startTransition] = useTransition()

  const handleGetRecommendations = async () => {
    if (!selectedAgeGroup || selectedInterests.length === 0) {
      return
    }

    startTransition(async () => {
      const formData = new FormData()
      formData.append("ageGroup", selectedAgeGroup)
      selectedInterests.forEach((interest) => formData.append("interests", interest))
      if (readingLevel) formData.append("readingLevel", readingLevel)

      const result = await getPersonalizedRecommendations(formData)

      if (result.success) {
        setRecommendations(result.recommendations)
        setExplanation(result.explanation)
      } else {
        console.error("Recommendations failed:", result.message)
      }
    })
  }

  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) => (prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]))
  }

  const canGetRecommendations = selectedAgeGroup && selectedInterests.length > 0

  return (
    <div className="space-y-6">
      {/* Preferences Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-warm-blue" />
            Get AI-Powered Book Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Age Group Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Child's Age Group *</label>
            <Select value={selectedAgeGroup} onValueChange={setSelectedAgeGroup}>
              <SelectTrigger>
                <SelectValue placeholder="Select age group" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-3">Baby & Toddler (0-3)</SelectItem>
                <SelectItem value="4-6">Preschool (4-6)</SelectItem>
                <SelectItem value="7-9">Early Reader (7-9)</SelectItem>
                <SelectItem value="10-12">Tween (10-12)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Reading Level */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Reading Level (Optional)</label>
            <Select value={readingLevel} onValueChange={setReadingLevel}>
              <SelectTrigger>
                <SelectValue placeholder="Select reading level" />
              </SelectTrigger>
              <SelectContent>
                {readingLevels.map((level) => (
                  <SelectItem key={level.value} value={level.value}>
                    {level.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Interests Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Child's Interests * (Select at least one)
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {interests.map((interest) => (
                <div key={interest} className="flex items-center space-x-2">
                  <Checkbox
                    id={interest}
                    checked={selectedInterests.includes(interest)}
                    onCheckedChange={() => toggleInterest(interest)}
                  />
                  <label
                    htmlFor={interest}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {interest}
                  </label>
                </div>
              ))}
            </div>
            {selectedInterests.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {selectedInterests.map((interest) => (
                  <Badge key={interest} variant="outline" className="bg-warm-cream">
                    {interest}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Get Recommendations Button */}
          <Button
            onClick={handleGetRecommendations}
            disabled={!canGetRecommendations || isPending}
            className="w-full bg-warm-blue hover:bg-warm-blue/90 h-12"
          >
            {isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Getting Recommendations...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Get Personalized Recommendations
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Recommendations Results */}
      {recommendations.length > 0 && (
        <div className="space-y-6">
          {/* AI Explanation */}
          {explanation && (
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <Sparkles className="h-5 w-5 text-warm-blue mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Why We Chose These Books</h3>
                    <p className="text-gray-700 leading-relaxed">{explanation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommended Books */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Recommended Books for You</h2>
              <Button
                onClick={handleGetRecommendations}
                variant="outline"
                disabled={isPending}
                className="bg-transparent"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Get New Recommendations
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendations.map((book) => (
                <DatabaseBookCard key={book.id} book={book} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
