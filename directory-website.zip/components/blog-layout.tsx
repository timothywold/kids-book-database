"use client"

import Image from "next/image"
import Link from "next/link"
import { Calendar, Clock, User, Tag, TrendingUp, BookOpen, Users } from "lucide-react"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface BlogPost {
  id: string
  title: string
  excerpt: string
  author: string
  publishDate: string
  readTime: string
  featuredImage: string
  tags: string[]
  category: string
  slug: string
  isPopular?: boolean
  viewCount?: number
}

interface SidebarItem {
  title: string
  description?: string
  link: string
  image?: string
  count?: number
}

const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "10 Bedtime Books Kids Love in 2025",
    excerpt:
      "Discover the most beloved bedtime stories that help children wind down and develop healthy sleep routines. From classic tales to modern favorites, these books create magical bedtime experiences.",
    author: "Sarah Johnson",
    publishDate: "2025-01-08",
    readTime: "5 min read",
    featuredImage: "/placeholder.svg?height=300&width=500",
    tags: ["bedtime books", "sleep routines", "picture books"],
    category: "Book Lists",
    slug: "10-bedtime-books-kids-love-2025",
    isPopular: true,
    viewCount: 12450,
  },
  {
    id: "2",
    title: "How to Encourage Early Reading at Home",
    excerpt:
      "Expert tips and strategies for parents to foster a love of reading in young children. Learn practical techniques to make reading fun and engaging for kids of all ages.",
    author: "Dr. Emily Chen",
    publishDate: "2025-01-05",
    readTime: "8 min read",
    featuredImage: "/placeholder.svg?height=300&width=500",
    tags: ["early literacy", "parenting tips", "reading strategies"],
    category: "Parenting",
    slug: "encourage-early-reading-at-home",
    isPopular: true,
    viewCount: 8920,
  },
  {
    id: "3",
    title: "New Releases from Indie Children's Authors",
    excerpt:
      "Spotlight on talented independent authors creating amazing children's books. Discover hidden gems and support diverse voices in children's literature.",
    author: "Marcus Williams",
    publishDate: "2025-01-03",
    readTime: "6 min read",
    featuredImage: "/placeholder.svg?height=300&width=500",
    tags: ["indie authors", "new releases", "diverse books"],
    category: "Author Spotlight",
    slug: "new-releases-indie-children-authors",
    viewCount: 5670,
  },
  {
    id: "4",
    title: "STEM Books That Make Science Fun for Kids",
    excerpt:
      "Engaging science, technology, engineering, and math books that spark curiosity and learning. Perfect for young scientists and future innovators.",
    author: "Dr. Rachel Martinez",
    publishDate: "2025-01-01",
    readTime: "7 min read",
    featuredImage: "/placeholder.svg?height=300&width=500",
    tags: ["STEM books", "science", "educational"],
    category: "Educational",
    slug: "stem-books-make-science-fun-kids",
    isPopular: true,
    viewCount: 7340,
  },
  {
    id: "5",
    title: "Building Your Child's Home Library on a Budget",
    excerpt:
      "Smart strategies for creating an amazing book collection without breaking the bank. Tips for finding quality books at great prices.",
    author: "Jennifer Davis",
    publishDate: "2024-12-28",
    readTime: "5 min read",
    featuredImage: "/placeholder.svg?height=300&width=500",
    tags: ["budget tips", "home library", "book collecting"],
    category: "Parenting",
    slug: "building-child-home-library-budget",
    viewCount: 4280,
  },
  {
    id: "6",
    title: "Award-Winning Books Every Child Should Read",
    excerpt:
      "A curated list of Caldecott, Newbery, and other prestigious award winners that have stood the test of time and continue to inspire young readers.",
    author: "Lisa Thompson",
    publishDate: "2024-12-25",
    readTime: "9 min read",
    featuredImage: "/placeholder.svg?height=300&width=500",
    tags: ["award winners", "classic books", "must-read"],
    category: "Book Lists",
    slug: "award-winning-books-every-child-should-read",
    viewCount: 6150,
  },
]

const popularPosts: SidebarItem[] = [
  {
    title: "10 Bedtime Books Kids Love in 2025",
    link: "/blog/10-bedtime-books-kids-love-2025",
    count: 12450,
  },
  {
    title: "How to Encourage Early Reading at Home",
    link: "/blog/encourage-early-reading-at-home",
    count: 8920,
  },
  {
    title: "STEM Books That Make Science Fun for Kids",
    link: "/blog/stem-books-make-science-fun-kids",
    count: 7340,
  },
  {
    title: "Award-Winning Books Every Child Should Read",
    link: "/blog/award-winning-books-every-child-should-read",
    count: 6150,
  },
]

const booksByTheme: SidebarItem[] = [
  {
    title: "Bedtime & Sleep Stories",
    description: "Soothing books for peaceful nights",
    link: "/themes/bedtime",
    image: "/placeholder.svg?height=60&width=60",
    count: 145,
  },
  {
    title: "STEM & Science Adventures",
    description: "Books that make learning fun",
    link: "/themes/stem",
    image: "/placeholder.svg?height=60&width=60",
    count: 89,
  },
  {
    title: "Friendship & Social Skills",
    description: "Stories about relationships",
    link: "/themes/friendship",
    image: "/placeholder.svg?height=60&width=60",
    count: 167,
  },
  {
    title: "Diversity & Inclusion",
    description: "Celebrating all children",
    link: "/themes/diversity",
    image: "/placeholder.svg?height=60&width=60",
    count: 203,
  },
]

const parentResources: SidebarItem[] = [
  {
    title: "Reading Milestone Checklist",
    description: "Track your child's reading development",
    link: "/resources/reading-milestones",
  },
  {
    title: "Age-Appropriate Book Guide",
    description: "Find the right books for every age",
    link: "/resources/age-guide",
  },
  {
    title: "Reading Activities & Games",
    description: "Fun ways to practice reading skills",
    link: "/resources/reading-activities",
  },
  {
    title: "Dealing with Reluctant Readers",
    description: "Strategies to motivate hesitant children",
    link: "/resources/reluctant-readers",
  },
  {
    title: "Building Reading Comprehension",
    description: "Help kids understand what they read",
    link: "/resources/reading-comprehension",
  },
]

export function BlogLayout() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Blog",
    name: "BookWonders Children's Book Blog",
    description: "Expert advice on children's books, reading tips, and literacy development for parents and educators",
    url: "https://bookwonders.com/blog",
    author: {
      "@type": "Organization",
      name: "BookWonders",
    },
    blogPost: blogPosts.map((post) => ({
      "@type": "BlogPosting",
      headline: post.title,
      description: post.excerpt,
      author: {
        "@type": "Person",
        name: post.author,
      },
      datePublished: post.publishDate,
      url: `https://bookwonders.com/blog/${post.slug}`,
      image: post.featuredImage,
      keywords: post.tags.join(", "),
    })),
  }

  return (
    <div className="container px-4 md:px-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4">Children's Book Blog</h1>
        <p className="text-xl text-gray-700 max-w-3xl mx-auto">
          Expert advice, book recommendations, and reading tips to help your child develop a lifelong love of books
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-3">
          <div className="space-y-8">
            {blogPosts.map((post, index) => (
              <BlogPostCard key={post.id} post={post} featured={index === 0} />
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-center mt-12">
            <div className="flex items-center space-x-2">
              <Button variant="outline" className="bg-transparent">
                Previous
              </Button>
              <Button className="bg-warm-blue hover:bg-warm-blue/90">1</Button>
              <Button variant="outline" className="bg-transparent">
                2
              </Button>
              <Button variant="outline" className="bg-transparent">
                3
              </Button>
              <Button variant="outline" className="bg-transparent">
                Next
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-6 space-y-8">
            {/* Most Popular Posts */}
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-warm-blue" />
                  <h3 className="text-lg font-bold">Most Popular Posts</h3>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {popularPosts.map((post, index) => (
                  <div key={index} className="flex items-start space-x-3 group">
                    <div className="flex-shrink-0 w-8 h-8 bg-warm-blue text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link
                        href={post.link}
                        className="text-sm font-medium text-gray-900 group-hover:text-warm-blue transition-colors line-clamp-2"
                      >
                        {post.title}
                      </Link>
                      <p className="text-xs text-gray-500 mt-1">{post.count?.toLocaleString()} views</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Books by Theme */}
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5 text-warm-blue" />
                  <h3 className="text-lg font-bold">Books by Theme</h3>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {booksByTheme.map((theme, index) => (
                  <Link key={index} href={theme.link} className="block group">
                    <div className="flex items-center space-x-3">
                      <div className="flex-shrink-0">
                        <Image
                          src={theme.image || "/placeholder.svg"}
                          alt={`${theme.title} book collection`}
                          width={48}
                          height={48}
                          className="rounded-lg object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-gray-900 group-hover:text-warm-blue transition-colors">
                          {theme.title}
                        </h4>
                        <p className="text-xs text-gray-500 line-clamp-1">{theme.description}</p>
                        <p className="text-xs text-warm-blue font-medium">{theme.count} books</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </CardContent>
            </Card>

            {/* Parent Resources */}
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-warm-blue" />
                  <h3 className="text-lg font-bold">Parent Resources</h3>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {parentResources.map((resource, index) => (
                  <Link key={index} href={resource.link} className="block group">
                    <div className="p-3 rounded-lg border border-gray-200 group-hover:border-warm-blue transition-colors">
                      <h4 className="text-sm font-medium text-gray-900 group-hover:text-warm-blue transition-colors">
                        {resource.title}
                      </h4>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2">{resource.description}</p>
                    </div>
                  </Link>
                ))}
              </CardContent>
            </Card>

            {/* Newsletter Signup */}
            <Card className="bg-gradient-to-br from-warm-blue to-blue-500 text-white">
              <CardContent className="p-6 text-center">
                <h3 className="text-lg font-bold mb-2">Stay Updated</h3>
                <p className="text-sm opacity-90 mb-4">Get weekly reading tips and book recommendations</p>
                <div className="space-y-2">
                  <input
                    type="email"
                    placeholder="Your email"
                    className="w-full px-3 py-2 rounded-lg text-gray-900 text-sm"
                  />
                  <Button className="w-full bg-warm-yellow hover:bg-warm-yellow/90 text-gray-900 font-semibold">
                    Subscribe
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

function BlogPostCard({ post, featured = false }: { post: BlogPost; featured?: boolean }) {
  return (
    <Card
      className={`overflow-hidden transition-all duration-300 hover:shadow-lg ${featured ? "ring-2 ring-warm-yellow" : ""}`}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
        <div
          className={`relative ${featured ? "md:col-span-2" : "md:col-span-1"} aspect-video md:aspect-auto overflow-hidden`}
        >
          <Image
            src={post.featuredImage || "/placeholder.svg"}
            alt={`Featured image for blog post: ${post.title} - ${post.excerpt.split(".")[0]}`}
            fill
            className="object-cover transition-transform duration-300 hover:scale-105"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          />
          {featured && (
            <Badge className="absolute top-4 left-4 bg-warm-yellow text-gray-900 font-semibold">Featured Post</Badge>
          )}
          {post.isPopular && (
            <Badge className="absolute top-4 right-4 bg-red-500 text-white font-semibold">Popular</Badge>
          )}
        </div>

        <CardContent className={`${featured ? "md:col-span-1" : "md:col-span-2"} p-6 flex flex-col justify-between`}>
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500">
              <Badge variant="outline" className="text-xs bg-warm-cream">
                {post.category}
              </Badge>
              <div className="flex items-center space-x-1">
                <Calendar className="h-3 w-3" />
                <span>{new Date(post.publishDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="h-3 w-3" />
                <span>{post.readTime}</span>
              </div>
            </div>

            <div>
              <Link href={`/blog/${post.slug}`}>
                <h2
                  className={`font-bold text-gray-900 hover:text-warm-blue transition-colors line-clamp-2 ${featured ? "text-2xl" : "text-xl"}`}
                >
                  {post.title}
                </h2>
              </Link>
              <div className="flex items-center space-x-2 mt-2 text-sm text-gray-600">
                <User className="h-3 w-3" />
                <span>by {post.author}</span>
                {post.viewCount && (
                  <>
                    <span>•</span>
                    <span>{post.viewCount.toLocaleString()} views</span>
                  </>
                )}
              </div>
            </div>

            <p className="text-gray-700 line-clamp-3 leading-relaxed">{post.excerpt}</p>

            <div className="flex flex-wrap gap-2">
              {post.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs bg-gray-50 text-gray-600">
                  <Tag className="h-3 w-3 mr-1" />
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <Button className="bg-warm-blue hover:bg-warm-blue/90 text-white" asChild>
              <Link href={`/blog/${post.slug}`}>Read More</Link>
            </Button>
          </div>
        </CardContent>
      </div>
    </Card>
  )
}
