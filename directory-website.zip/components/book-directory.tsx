"use client"

import { useState, useMemo } from "react"
import Image from "next/image"
import Link from "next/link"
import { Star, Filter, ExternalLink, Info } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Book {
  id: string
  title: string
  author: string
  ageGroup: "0-3" | "4-6" | "7-9" | "10-12"
  rating: number
  reviewCount: number
  price: string
  image: string
  blurb: string
  category: string[]
  publishDate: string
  awards: string[]
  popularity: number
  isNew: boolean
  amazonUrl: string
  moreInfoUrl: string
}

const booksData: Book[] = [
  // Baby & Toddler (0-3)
  {
    id: "1",
    title: "Goodnight Moon",
    author: "Margaret Wise Brown",
    ageGroup: "0-3",
    rating: 4.8,
    reviewCount: 18750,
    price: "$8.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "The ultimate bedtime book for babies and toddlers. This soothing bedtime story helps establish nighttime routines with gentle rhymes and calming illustrations perfect for sleepy time reading.",
    category: ["bedtime", "classic"],
    publishDate: "1947-09-03",
    awards: [],
    popularity: 95,
    isNew: false,
    amazonUrl: "https://amazon.com/goodnight-moon",
    moreInfoUrl: "/books/goodnight-moon",
  },
  {
    id: "2",
    title: "The Very Hungry Caterpillar",
    author: "Eric Carle",
    ageGroup: "0-3",
    rating: 4.9,
    reviewCount: 15420,
    price: "$8.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "An award-winning board book that teaches counting, days of the week, and healthy eating habits. Perfect for interactive reading with toddlers learning colors and numbers through engaging storytelling.",
    category: ["educational", "interactive"],
    publishDate: "1969-06-03",
    awards: ["American Institute of Graphic Arts Award"],
    popularity: 98,
    isNew: false,
    amazonUrl: "https://amazon.com/very-hungry-caterpillar",
    moreInfoUrl: "/books/very-hungry-caterpillar",
  },
  {
    id: "3",
    title: "Baby Loves Coding",
    author: "Ruth Spiro",
    ageGroup: "0-3",
    rating: 4.6,
    reviewCount: 892,
    price: "$9.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Introduce STEM concepts to babies with this innovative board book series. Early STEM learning made simple with colorful illustrations teaching basic coding concepts and problem-solving skills for curious minds.",
    category: ["STEM", "educational"],
    publishDate: "2017-10-10",
    awards: [],
    popularity: 78,
    isNew: true,
    amazonUrl: "https://amazon.com/baby-loves-coding",
    moreInfoUrl: "/books/baby-loves-coding",
  },

  // Preschool (4-6)
  {
    id: "4",
    title: "The Day the Crayons Quit",
    author: "Drew Daywalt",
    ageGroup: "4-6",
    rating: 4.8,
    reviewCount: 11240,
    price: "$7.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Award-winning picture book that sparks creativity and teaches colors through humor. Perfect bedtime story that encourages artistic expression and problem-solving while entertaining preschoolers with laugh-out-loud moments.",
    category: ["humor", "creativity"],
    publishDate: "2013-06-27",
    awards: ["Goodreads Choice Award"],
    popularity: 92,
    isNew: false,
    amazonUrl: "https://amazon.com/day-crayons-quit",
    moreInfoUrl: "/books/day-crayons-quit",
  },
  {
    id: "5",
    title: "Ada Twist, Scientist",
    author: "Andrea Beaty",
    ageGroup: "4-6",
    rating: 4.7,
    reviewCount: 6840,
    price: "$9.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Inspiring STEM stories for young girls featuring a curious scientist. This award-winning picture book encourages scientific thinking and experimentation, perfect for budding scientists and STEAM education.",
    category: ["STEM", "empowerment"],
    publishDate: "2016-09-06",
    awards: ["Parents' Choice Gold Award"],
    popularity: 89,
    isNew: false,
    amazonUrl: "https://amazon.com/ada-twist-scientist",
    moreInfoUrl: "/books/ada-twist-scientist",
  },
  {
    id: "6",
    title: "Dragons Love Tacos",
    author: "Adam Rubin",
    ageGroup: "4-6",
    rating: 4.6,
    reviewCount: 8920,
    price: "$8.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Hilarious picture book perfect for bedtime reading and family story time. This funny tale about dragons and their taco obsession teaches friendship and consequences through engaging storytelling and vibrant illustrations.",
    category: ["humor", "friendship"],
    publishDate: "2012-05-01",
    awards: [],
    popularity: 85,
    isNew: false,
    amazonUrl: "https://amazon.com/dragons-love-tacos",
    moreInfoUrl: "/books/dragons-love-tacos",
  },

  // Early Reader (7-9)
  {
    id: "7",
    title: "Dog Man: Mothering Heights",
    author: "Dav Pilkey",
    ageGroup: "7-9",
    rating: 4.7,
    reviewCount: 8920,
    price: "$5.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Latest chapter book in the beloved graphic novel series perfect for reluctant readers. Combines humor with important lessons about family, friendship, and doing the right thing in an engaging comic book format.",
    category: ["graphic novel", "humor"],
    publishDate: "2021-03-23",
    awards: [],
    popularity: 94,
    isNew: true,
    amazonUrl: "https://amazon.com/dog-man-mothering-heights",
    moreInfoUrl: "/books/dog-man-mothering-heights",
  },
  {
    id: "8",
    title: "The Magic Tree House: Dinosaurs Before Dark",
    author: "Mary Pope Osborne",
    ageGroup: "7-9",
    rating: 4.5,
    reviewCount: 12450,
    price: "$6.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Award-winning early reader chapter book series combining adventure with educational content. Perfect for independent reading, this time-travel story teaches history and science while building reading confidence.",
    category: ["adventure", "educational"],
    publishDate: "1992-07-28",
    awards: ["Parents' Choice Award"],
    popularity: 91,
    isNew: false,
    amazonUrl: "https://amazon.com/magic-tree-house-dinosaurs",
    moreInfoUrl: "/books/magic-tree-house-dinosaurs",
  },
  {
    id: "9",
    title: "Ivy and Bean",
    author: "Annie Barrows",
    ageGroup: "7-9",
    rating: 4.4,
    reviewCount: 5670,
    price: "$6.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Beloved early reader series about friendship and adventure. These chapter books feature strong female characters and teach valuable lessons about friendship, problem-solving, and accepting differences.",
    category: ["friendship", "chapter book"],
    publishDate: "2006-09-01",
    awards: ["Book Sense Children's Pick"],
    popularity: 82,
    isNew: false,
    amazonUrl: "https://amazon.com/ivy-and-bean",
    moreInfoUrl: "/books/ivy-and-bean",
  },

  // Tween (10-12)
  {
    id: "10",
    title: "Wonder",
    author: "R.J. Palacio",
    ageGroup: "10-12",
    rating: 4.9,
    reviewCount: 25680,
    price: "$8.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Award-winning middle grade novel about kindness, acceptance, and anti-bullying. This powerful story teaches empathy and celebrates differences, perfect for tweens navigating social challenges and building character.",
    category: ["realistic fiction", "empathy"],
    publishDate: "2012-02-14",
    awards: ["Dorothy Canfield Fisher Children's Book Award"],
    popularity: 97,
    isNew: false,
    amazonUrl: "https://amazon.com/wonder-rj-palacio",
    moreInfoUrl: "/books/wonder",
  },
  {
    id: "11",
    title: "The Wild Robot",
    author: "Peter Brown",
    ageGroup: "10-12",
    rating: 4.8,
    reviewCount: 8940,
    price: "$9.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Award-winning STEM adventure combining robotics with nature themes. This middle grade novel explores technology, environmental science, and survival while teaching lessons about adaptation and belonging.",
    category: ["STEM", "adventure"],
    publishDate: "2016-09-27",
    awards: ["E.B. White Read-Aloud Award"],
    popularity: 88,
    isNew: false,
    amazonUrl: "https://amazon.com/wild-robot",
    moreInfoUrl: "/books/wild-robot",
  },
  {
    id: "12",
    title: "New Kid",
    author: "Jerry Craft",
    ageGroup: "10-12",
    rating: 4.6,
    reviewCount: 4320,
    price: "$12.99",
    image: "/placeholder.svg?height=300&width=200",
    blurb:
      "Newbery Medal-winning graphic novel about middle school challenges and diversity. This award-winning story addresses important topics like identity, friendship, and fitting in while providing engaging visual storytelling for tweens.",
    category: ["graphic novel", "diversity"],
    publishDate: "2019-02-05",
    awards: ["Newbery Medal", "Coretta Scott King Author Honor"],
    popularity: 86,
    isNew: true,
    amazonUrl: "https://amazon.com/new-kid",
    moreInfoUrl: "/books/new-kid",
  },
]

type SortOption = "popularity" | "new" | "award-winning"
type AgeGroup = "0-3" | "4-6" | "7-9" | "10-12"

export function BookDirectory() {
  const [activeTab, setActiveTab] = useState<AgeGroup>("0-3")
  const [sortBy, setSortBy] = useState<SortOption>("popularity")

  const ageGroupLabels = {
    "0-3": "Baby & Toddler",
    "4-6": "Preschool",
    "7-9": "Early Reader",
    "10-12": "Tween",
  }

  const filteredAndSortedBooks = useMemo(() => {
    const filtered = booksData.filter((book) => book.ageGroup === activeTab)

    switch (sortBy) {
      case "popularity":
        return filtered.sort((a, b) => b.popularity - a.popularity)
      case "new":
        return filtered.sort((a, b) => {
          if (a.isNew && !b.isNew) return -1
          if (!a.isNew && b.isNew) return 1
          return new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
        })
      case "award-winning":
        return filtered.sort((a, b) => b.awards.length - a.awards.length)
      default:
        return filtered
    }
  }, [activeTab, sortBy])

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: `Children's Books for Ages ${activeTab}`,
    description: `Curated collection of ${ageGroupLabels[activeTab].toLowerCase()} books including bedtime stories, STEM books, and award-winning titles`,
    itemListElement: filteredAndSortedBooks.map((book, index) => ({
      "@type": "Book",
      position: index + 1,
      name: book.title,
      author: {
        "@type": "Person",
        name: book.author,
      },
      description: book.blurb,
      aggregateRating: {
        "@type": "AggregateRating",
        ratingValue: book.rating,
        reviewCount: book.reviewCount,
      },
      audience: {
        "@type": "PeopleAudience",
        suggestedMinAge: book.ageGroup.split("-")[0],
        suggestedMaxAge: book.ageGroup.split("-")[1],
      },
    })),
  }

  return (
    <div className="container px-4 md:px-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      <div className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4">Children's Book Directory</h1>
        <p className="text-xl text-gray-700 max-w-3xl mx-auto">
          Discover the perfect books for every age group. From bedtime stories and STEM adventures to award-winning
          tales that inspire young minds.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as AgeGroup)} className="w-full">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
          <TabsList className="grid w-full lg:w-auto grid-cols-2 lg:grid-cols-4 h-auto p-1 bg-warm-cream">
            <TabsTrigger
              value="0-3"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Baby & Toddler</span>
              <span className="text-xs opacity-75">Ages 0–3</span>
            </TabsTrigger>
            <TabsTrigger
              value="4-6"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Preschool</span>
              <span className="text-xs opacity-75">Ages 4–6</span>
            </TabsTrigger>
            <TabsTrigger
              value="7-9"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Early Reader</span>
              <span className="text-xs opacity-75">Ages 7–9</span>
            </TabsTrigger>
            <TabsTrigger
              value="10-12"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Tween</span>
              <span className="text-xs opacity-75">Ages 10–12</span>
            </TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Sort by:</span>
            </div>
            <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
              <SelectTrigger className="w-[180px] bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Most Popular</SelectItem>
                <SelectItem value="new">Newest First</SelectItem>
                <SelectItem value="award-winning">Award Winners</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="0-3" className="mt-0">
          <BookGrid books={filteredAndSortedBooks} ageGroup="Baby & Toddler" />
        </TabsContent>
        <TabsContent value="4-6" className="mt-0">
          <BookGrid books={filteredAndSortedBooks} ageGroup="Preschool" />
        </TabsContent>
        <TabsContent value="7-9" className="mt-0">
          <BookGrid books={filteredAndSortedBooks} ageGroup="Early Reader" />
        </TabsContent>
        <TabsContent value="10-12" className="mt-0">
          <BookGrid books={filteredAndSortedBooks} ageGroup="Tween" />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function BookGrid({ books, ageGroup }: { books: Book[]; ageGroup: string }) {
  if (books.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">No books found for this category.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">
          {ageGroup} Books ({books.length})
        </h2>
        <p className="text-gray-600">
          Showing {books.length} book{books.length !== 1 ? "s" : ""}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {books.map((book) => (
          <BookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  )
}

function BookCard({ book }: { book: Book }) {
  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative aspect-[3/4] overflow-hidden bg-gray-100">
        <Image
          src={book.image || "/placeholder.svg"}
          alt={`Cover of "${book.title}" by ${book.author} - ${book.blurb.split(".")[0]}`}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />

        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {book.isNew && <Badge className="bg-green-500 text-white font-semibold">New Release</Badge>}
          {book.awards.length > 0 && <Badge className="bg-warm-yellow text-gray-900 font-semibold">Award Winner</Badge>}
        </div>

        <Badge variant="outline" className="absolute top-3 right-3 bg-white/90 text-gray-700 font-medium">
          Ages {book.ageGroup}
        </Badge>
      </div>

      <CardContent className="p-5 space-y-4">
        <div className="space-y-2">
          <h3 className="font-bold text-lg leading-tight line-clamp-2 group-hover:text-warm-blue transition-colors">
            {book.title}
          </h3>
          <p className="text-gray-600 font-medium">by {book.author}</p>

          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(book.rating) ? "fill-warm-yellow text-warm-yellow" : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm font-medium">{book.rating}</span>
            <span className="text-sm text-gray-500">({book.reviewCount.toLocaleString()})</span>
          </div>
        </div>

        <p className="text-sm text-gray-700 line-clamp-3 leading-relaxed">{book.blurb}</p>

        <div className="flex flex-wrap gap-1">
          {book.category.slice(0, 2).map((cat) => (
            <Badge key={cat} variant="outline" className="text-xs bg-warm-cream text-gray-700">
              {cat}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between pt-2">
          <span className="text-lg font-bold text-warm-blue">{book.price}</span>
          {book.awards.length > 0 && (
            <span className="text-xs text-gray-500">
              {book.awards.length} award{book.awards.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>

        <div className="flex flex-col space-y-2 pt-2">
          <Button className="w-full bg-warm-blue hover:bg-warm-blue/90 text-white font-semibold" asChild>
            <Link href={book.amazonUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4 mr-2" />
              Buy Now
            </Link>
          </Button>
          <Button
            variant="outline"
            className="w-full border-warm-blue text-warm-blue hover:bg-warm-blue hover:text-white font-semibold bg-transparent"
            asChild
          >
            <Link href={book.moreInfoUrl}>
              <Info className="h-4 w-4 mr-2" />
              More Info
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
