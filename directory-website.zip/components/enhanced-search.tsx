"use client"

import type React from "react"

import { useState, useTransition } from "react"
import { Search, Filter, Loader2, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { performBookSearch } from "@/app/actions/search"
import type { Book } from "@/lib/database"
import { DatabaseBookCard } from "./enhanced-book-directory"

const categories = [
  "picture book",
  "chapter book",
  "graphic novel",
  "STEM",
  "bedtime",
  "humor",
  "adventure",
  "friendship",
  "classic",
  "educational",
  "fantasy",
  "mystery",
]

const ageGroups = [
  { value: "0-3", label: "Baby & Toddler (0-3)" },
  { value: "4-6", label: "Preschool (4-6)" },
  { value: "7-9", label: "Early Reader (7-9)" },
  { value: "10-12", label: "Tween (10-12)" },
]

export function EnhancedSearch() {
  const [query, setQuery] = useState("")
  const [selectedAgeGroup, setSelectedAgeGroup] = useState("any")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [minRating, setMinRating] = useState("any")
  const [results, setResults] = useState<Book[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [isPending, startTransition] = useTransition()

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()

    startTransition(async () => {
      const formData = new FormData()
      formData.append("query", query)
      if (selectedAgeGroup !== "any") formData.append("ageGroup", selectedAgeGroup)
      selectedCategories.forEach((cat) => formData.append("categories", cat))
      if (minRating !== "any") formData.append("minRating", minRating)

      const result = await performBookSearch(formData)

      if (result.success) {
        setResults(result.results)
        setSearchQuery(result.query)
      } else {
        console.error("Search failed:", result.message)
        setResults([])
      }
    })
  }

  const clearFilters = () => {
    setSelectedAgeGroup("any")
    setSelectedCategories([])
    setMinRating("any")
  }

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const activeFiltersCount = [
    selectedAgeGroup !== "any" ? selectedAgeGroup : null,
    ...selectedCategories,
    minRating !== "any" ? minRating : null,
  ].filter(Boolean).length

  return (
    <div className="space-y-6">
      {/* Search Form */}
      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  type="search"
                  placeholder="Search for books, authors, or topics..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="pl-10 h-12 text-lg"
                />
              </div>
              <Button type="submit" disabled={isPending} className="bg-warm-blue hover:bg-warm-blue/90 h-12 px-8">
                {isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </>
                )}
              </Button>
            </div>

            {/* Filter Toggle */}
            <div className="flex items-center justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="bg-transparent"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
                {activeFiltersCount > 0 && <Badge className="ml-2 bg-warm-blue text-white">{activeFiltersCount}</Badge>}
              </Button>

              {activeFiltersCount > 0 && (
                <Button
                  type="button"
                  variant="ghost"
                  onClick={clearFilters}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-4 w-4 mr-1" />
                  Clear Filters
                </Button>
              )}
            </div>

            {/* Filters */}
            {showFilters && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 bg-gray-50 rounded-lg">
                {/* Age Group Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Age Group</label>
                  <Select value={selectedAgeGroup} onValueChange={setSelectedAgeGroup}>
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Any age" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any age</SelectItem>
                      {ageGroups.map((group) => (
                        <SelectItem key={group.value} value={group.value}>
                          {group.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Rating Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Minimum Rating</label>
                  <Select value={minRating} onValueChange={setMinRating}>
                    <SelectTrigger className="bg-white">
                      <SelectValue placeholder="Any rating" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any rating</SelectItem>
                      <SelectItem value="4">4+ Stars</SelectItem>
                      <SelectItem value="4.5">4.5+ Stars</SelectItem>
                      <SelectItem value="4.8">4.8+ Stars</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Categories Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Categories</label>
                  <div className="max-h-32 overflow-y-auto space-y-2">
                    {categories.map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox
                          id={category}
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() => toggleCategory(category)}
                        />
                        <label
                          htmlFor={category}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                        >
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </form>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchQuery && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Search Results for "{searchQuery}"</h2>
            <p className="text-gray-600">
              {results.length} book{results.length !== 1 ? "s" : ""} found
            </p>
          </div>

          {results.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((book) => (
                <DatabaseBookCard key={book.id} book={book} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-500 text-lg mb-4">No books found matching your search criteria.</p>
                <p className="text-gray-400">Try adjusting your search terms or filters.</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
