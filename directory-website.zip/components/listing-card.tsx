import Link from "next/link"
import Image from "next/image"
import { Star, MapPin } from "lucide-react"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface ListingCardProps {
  title: string
  category: string
  rating: number
  reviews: number
  address: string
  image: string
  href: string
}

export function ListingCard({ title, category, rating, reviews, address, image, href }: ListingCardProps) {
  return (
    <Card className="overflow-hidden">
      <Link href={href}>
        <div className="relative aspect-video overflow-hidden">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            fill
            className="object-cover transition-transform hover:scale-105"
          />
          <Badge className="absolute top-2 right-2">{category}</Badge>
        </div>
      </Link>
      <CardContent className="p-4">
        <Link href={href}>
          <h3 className="text-lg font-semibold hover:underline">{title}</h3>
        </Link>
        <div className="flex items-center mt-1">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span className="ml-1 text-sm font-medium">{rating}</span>
          <span className="ml-1 text-sm text-muted-foreground">({reviews} reviews)</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex items-center text-sm text-muted-foreground">
        <MapPin className="h-4 w-4 mr-1" />
        {address}
      </CardFooter>
    </Card>
  )
}
