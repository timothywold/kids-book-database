"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Database, Facebook, Twitter, Instagram, PinIcon as Pinterest, Youtube, Mail, Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const socialLinks = [
  {
    name: "Instagram",
    href: "https://instagram.com/childrensbookdirectory",
    icon: Instagram,
    color: "hover:text-pink-500",
  },
  {
    name: "Pinterest",
    href: "https://pinterest.com/childrensbookdirectory",
    icon: Pinterest,
    color: "hover:text-red-500",
  },
  {
    name: "Facebook",
    href: "https://facebook.com/childrensbookdirectory",
    icon: Facebook,
    color: "hover:text-blue-600",
  },
  {
    name: "Twitter",
    href: "https://twitter.com/childrensbookdirectory",
    icon: Twitter,
    color: "hover:text-blue-400",
  },
  {
    name: "YouTube",
    href: "https://youtube.com/childrensbookdirectory",
    icon: Youtube,
    color: "hover:text-red-600",
  },
]

const footerLinks = {
  "Browse Books": [
    { name: "Ages 0-3", href: "/age/0-3" },
    { name: "Ages 4-6", href: "/age/4-6" },
    { name: "Ages 7-9", href: "/age/7-9" },
    { name: "Ages 10-12", href: "/age/10-12" },
    { name: "New Releases", href: "/new-releases" },
    { name: "Award Winners", href: "/award-winners" },
  ],
  Resources: [
    { name: "Reading Guides", href: "/resources/reading-guides" },
    { name: "Book Lists", href: "/resources/book-lists" },
    { name: "Author Interviews", href: "/blog/category/interviews" },
    { name: "Reading Tips", href: "/blog/category/tips" },
    { name: "STEM Books", href: "/themes/stem" },
    { name: "Bedtime Stories", href: "/themes/bedtime" },
  ],
  About: [
    { name: "About the Author", href: "/about" },
    { name: "Our Mission", href: "/about#mission" },
    { name: "Contact Us", href: "/contact" },
    { name: "Press Kit", href: "/press" },
    { name: "Partnerships", href: "/partnerships" },
    { name: "Testimonials", href: "/testimonials" },
  ],
  Support: [
    { name: "Help Center", href: "/help" },
    { name: "FAQ", href: "/faq" },
    { name: "Privacy Policy", href: "/privacy" },
    { name: "Terms of Service", href: "/terms" },
    { name: "Cookie Policy", href: "/cookies" },
    { name: "Accessibility", href: "/accessibility" },
  ],
}

export function Footer() {
  const [email, setEmail] = useState("")
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSubscribed(true)
    setIsLoading(false)
    setEmail("")

    // Reset success message after 3 seconds
    setTimeout(() => setIsSubscribed(false), 3000)
  }

  return (
    <footer className="bg-gray-900 text-white">
      {/* Newsletter Section */}
      <div className="bg-gradient-to-r from-warm-blue to-blue-600">
        <div className="container px-4 md:px-6 py-12">
          <div className="max-w-2xl mx-auto text-center">
            <div className="flex items-center justify-center mb-4">
              <Mail className="h-8 w-8 mr-3" />
              <h2 className="text-2xl md:text-3xl font-bold font-display">Get Weekly Book Picks</h2>
            </div>
            <p className="text-lg opacity-90 mb-6">
              Discover amazing children's books curated by experts. Join 50,000+ parents and teachers who trust our
              recommendations.
            </p>

            {isSubscribed ? (
              <div className="bg-green-500 text-white px-6 py-3 rounded-full inline-flex items-center">
                <Heart className="h-5 w-5 mr-2" />
                <span className="font-semibold">Thank you for subscribing!</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <Input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-full text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white bg-white"
                  required
                />
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="bg-warm-yellow hover:bg-warm-yellow/90 text-gray-900 font-semibold px-8 py-3 rounded-full whitespace-nowrap"
                >
                  {isLoading ? "Subscribing..." : "Subscribe"}
                </Button>
              </form>
            )}

            <p className="text-sm mt-4 opacity-75">No spam, unsubscribe anytime. We respect your privacy.</p>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1 space-y-4">
            <Link className="flex flex-col items-start" href="/">
              <div className="flex items-center space-x-2">
                <Database className="h-8 w-8 text-warm-yellow" />
                <span className="font-bold text-xl font-display">Children's Book Directory</span>
              </div>
              <span className="text-xs text-gray-400 mt-1">ChildrensBookDirectory.com</span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              The most comprehensive directory of children's books. Helping families and educators discover amazing
              books since 2020.
            </p>

            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => {
                const Icon = social.icon
                return (
                  <Link
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`text-gray-400 transition-colors ${social.color}`}
                    aria-label={`Follow us on ${social.name}`}
                  >
                    <Icon className="h-5 w-5" />
                  </Link>
                )
              })}
            </div>
          </div>

          {/* Footer Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="space-y-4">
              <h3 className="font-semibold text-lg text-white">{category}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href} className="text-gray-400 hover:text-white transition-colors text-sm">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm text-gray-400">
              <p>&copy; 2025 Children's Book Directory. All rights reserved.</p>
              <div className="flex items-center space-x-4">
                <Link href="/privacy" className="hover:text-white transition-colors">
                  Privacy Policy
                </Link>
                <span>•</span>
                <Link href="/terms" className="hover:text-white transition-colors">
                  Terms of Service
                </Link>
                <span>•</span>
                <Link href="/cookies" className="hover:text-white transition-colors">
                  Cookie Policy
                </Link>
              </div>
            </div>

            <div className="flex items-center text-sm text-gray-400">
              <span>Made with</span>
              <Heart className="h-4 w-4 mx-1 text-red-500" />
              <span>for young readers</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
