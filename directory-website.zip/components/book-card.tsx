import Image from "next/image"
import Link from "next/link"
import { Star, ShoppingCart } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

interface BookCardProps {
  title: string
  author: string
  ageGroup: string
  rating: number
  price: string
  image: string
  badge?: string
  featured?: boolean
}

export function BookCard({ title, author, ageGroup, rating, price, image, badge, featured = false }: BookCardProps) {
  return (
    <Card
      className={`group overflow-hidden transition-all duration-300 hover:shadow-lg ${featured ? "ring-2 ring-warm-yellow" : ""}`}
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={`Cover of ${title} by ${author}`}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {badge && <Badge className="absolute top-2 left-2 bg-warm-yellow text-gray-900 font-semibold">{badge}</Badge>}
        <Badge variant="outline" className="absolute top-2 right-2 bg-white/90 text-gray-700">
          Ages {ageGroup}
        </Badge>
      </div>

      <CardContent className="p-4 space-y-3">
        <div>
          <h3 className="font-semibold text-lg leading-tight line-clamp-2 group-hover:text-warm-blue transition-colors">
            <Link href={`/books/${title.toLowerCase().replace(/\s+/g, "-")}`}>{title}</Link>
          </h3>
          <p className="text-gray-600 text-sm">by {author}</p>
        </div>

        <div className="flex items-center space-x-1">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${i < Math.floor(rating) ? "fill-warm-yellow text-warm-yellow" : "text-gray-300"}`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-600">({rating})</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-warm-blue">{price}</span>
          <Button size="sm" className="bg-warm-blue hover:bg-warm-blue/90">
            <ShoppingCart className="h-4 w-4 mr-1" />
            Add to Cart
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
