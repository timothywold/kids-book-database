import Link from "next/link"
import { Utensils, ShoppingBag, Heart, Briefcase } from "lucide-react"

import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface CategoryCardProps {
  title: string
  icon: string
  count: number
  href: string
}

export function CategoryCard({ title, icon, count, href }: CategoryCardProps) {
  const getIcon = () => {
    switch (icon) {
      case "utensils":
        return <Utensils className="h-8 w-8" />
      case "shopping-bag":
        return <ShoppingBag className="h-8 w-8" />
      case "heart":
        return <Heart className="h-8 w-8" />
      case "briefcase":
        return <Briefcase className="h-8 w-8" />
      default:
        return <Briefcase className="h-8 w-8" />
    }
  }

  return (
    <Link href={href}>
      <Card className="overflow-hidden hover:shadow-md transition-shadow">
        <CardContent className="p-6 flex flex-col items-center text-center">
          <div className="p-3 bg-primary/10 rounded-full mb-4">{getIcon()}</div>
          <h3 className="text-lg font-semibold">{title}</h3>
        </CardContent>
        <CardFooter className="p-4 pt-0 text-center text-sm text-muted-foreground">{count} listings</CardFooter>
      </Card>
    </Link>
  )
}
