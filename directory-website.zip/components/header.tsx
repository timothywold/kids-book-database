"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Database, Search, Menu, Settings } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

const navigationLinks = [
  { href: "/", label: "Home" },
  { href: "/directory", label: "Browse Books" },
  { href: "/search", label: "Search" },
  { href: "/recommendations", label: "AI Picks" },
  { href: "/blog", label: "Blog" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
]

const adminLinks = [
  { href: "/test", label: "Test" },
  { href: "/setup", label: "Setup" },
  { href: "/admin", label: "Admin" },
]

export function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  const isActiveLink = (href: string) => {
    if (href === "/") {
      return pathname === "/"
    }
    return pathname.startsWith(href)
  }

  const allLinks = [...navigationLinks, ...adminLinks]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80 shadow-sm">
      <div className="container flex h-20 items-center justify-between px-4 md:px-6">
        {/* Logo */}
        <Link className="flex flex-col items-start hover:opacity-80 transition-opacity" href="/">
          <div className="flex items-center space-x-2">
            <Database className="h-8 w-8 text-warm-blue" />
            <span className="font-bold text-xl font-display text-gray-900">Children's Book Directory</span>
          </div>
          <span className="text-xs text-gray-600 mt-1 hidden sm:block">
            Discover the Best Books for Kids by Age, Topic & Theme
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-6">
          {navigationLinks.map((link) => (
            <Link
              key={link.href}
              className={`text-sm font-medium transition-colors hover:text-warm-blue relative ${
                isActiveLink(link.href)
                  ? "text-warm-blue after:absolute after:bottom-[-20px] after:left-0 after:right-0 after:h-0.5 after:bg-warm-blue"
                  : "text-gray-700"
              }`}
              href={link.href}
            >
              {link.label}
            </Link>
          ))}

          {/* Admin Dropdown */}
          <div className="flex items-center space-x-2 border-l pl-4 ml-2">
            <Link
              href="/admin"
              className={`flex items-center space-x-1 text-sm font-medium transition-colors hover:text-warm-blue ${
                pathname.startsWith("/admin") ? "text-warm-blue" : "text-gray-700"
              }`}
            >
              <Settings className="h-4 w-4" />
              <span>Admin</span>
            </Link>
          </div>
        </nav>

        {/* Search and Mobile Menu */}
        <div className="flex items-center space-x-4">
          {/* Desktop Search */}
          <div className="hidden md:flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search books..."
                className="w-[200px] lg:w-[300px] pl-8 bg-gray-50 border-gray-200 focus:bg-white focus:border-warm-blue"
              />
            </div>
          </div>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <div className="flex flex-col space-y-6 mt-6">
                {/* Mobile Logo */}
                <Link className="flex flex-col items-start" href="/" onClick={() => setIsOpen(false)}>
                  <div className="flex items-center space-x-2">
                    <Database className="h-6 w-6 text-warm-blue" />
                    <span className="font-bold text-lg font-display text-gray-900">Children's Book Directory</span>
                  </div>
                  <span className="text-xs text-gray-600 mt-1">
                    Discover the Best Books for Kids by Age, Topic & Theme
                  </span>
                </Link>

                {/* Mobile Search */}
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    type="search"
                    placeholder="Search books..."
                    className="w-full pl-8 bg-gray-50 border-gray-200 focus:bg-white focus:border-warm-blue"
                  />
                </div>

                {/* Mobile Navigation Links */}
                <nav className="flex flex-col space-y-4">
                  {allLinks.map((link) => (
                    <Link
                      key={link.href}
                      className={`text-lg font-medium transition-colors hover:text-warm-blue ${
                        isActiveLink(link.href) ? "text-warm-blue" : "text-gray-700"
                      }`}
                      href={link.href}
                      onClick={() => setIsOpen(false)}
                    >
                      {link.label}
                    </Link>
                  ))}
                </nav>

                {/* Mobile CTA */}
                <div className="pt-6 border-t">
                  <Button className="w-full bg-warm-blue hover:bg-warm-blue/90" asChild>
                    <Link href="/directory" onClick={() => setIsOpen(false)}>
                      Browse the Directory
                    </Link>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
