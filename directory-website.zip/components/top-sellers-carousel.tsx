"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight, ExternalLink, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Book {
  id: string
  title: string
  author: string
  ageRange: string
  rating: number
  reviewCount: number
  price: {
    amazon: string
    barnesNoble: string
  }
  image: string
  amazonUrl: string
  barnesNobleUrl: string
  isbn: string
  publisher: string
  publishDate: string
  description: string
}

const topSellerBooks: Book[] = [
  {
    id: "1",
    title: "The Very Hungry Caterpillar",
    author: "Eric Carle",
    ageRange: "0-3",
    rating: 4.9,
    reviewCount: 15420,
    price: {
      amazon: "$8.99",
      barnesNoble: "$9.99",
    },
    image: "/placeholder.svg?height=400&width=300",
    amazonUrl: "https://amazon.com/Very-Hungry-Caterpillar-Eric-Carle/dp/0399226907",
    barnesNobleUrl: "https://www.barnesandnoble.com/w/very-hungry-caterpillar-eric-carle/1100170349",
    isbn: "9780399226908",
    publisher: "Philomel Books",
    publishDate: "1994-03-23",
    description: "A classic tale of a caterpillar's transformation into a beautiful butterfly.",
  },
  {
    id: "2",
    title: "Where the Wild Things Are",
    author: "Maurice Sendak",
    ageRange: "4-6",
    rating: 4.8,
    reviewCount: 12350,
    price: {
      amazon: "$9.99",
      barnesNoble: "$10.99",
    },
    image: "/placeholder.svg?height=400&width=300",
    amazonUrl: "https://amazon.com/Where-Wild-Things-Maurice-Sendak/dp/0060254920",
    barnesNobleUrl: "https://www.barnesandnoble.com/w/where-the-wild-things-are-maurice-sendak/1100170350",
    isbn: "9780060254926",
    publisher: "HarperCollins",
    publishDate: "1988-11-09",
    description: "Max's imaginative journey to the land of the Wild Things.",
  },
  {
    id: "3",
    title: "Dog Man: Mothering Heights",
    author: "Dav Pilkey",
    ageRange: "7-9",
    rating: 4.7,
    reviewCount: 8920,
    price: {
      amazon: "$5.99",
      barnesNoble: "$6.99",
    },
    image: "/placeholder.svg?height=400&width=300",
    amazonUrl: "https://amazon.com/Dog-Man-Mothering-Heights-Pilkey/dp/1338680439",
    barnesNobleUrl: "https://www.barnesandnoble.com/w/dog-man-mothering-heights-dav-pilkey/1139788531",
    isbn: "9781338680430",
    publisher: "Graphix",
    publishDate: "2021-03-23",
    description: "The latest adventure in the beloved Dog Man series.",
  },
  {
    id: "4",
    title: "Wonder",
    author: "R.J. Palacio",
    ageRange: "10-12",
    rating: 4.9,
    reviewCount: 25680,
    price: {
      amazon: "$8.99",
      barnesNoble: "$9.99",
    },
    image: "/placeholder.svg?height=400&width=300",
    amazonUrl: "https://amazon.com/Wonder-R-J-Palacio/dp/0375869026",
    barnesNobleUrl: "https://www.barnesandnoble.com/w/wonder-r-j-palacio/1110613439",
    isbn: "9780375869020",
    publisher: "Knopf Books for Young Readers",
    publishDate: "2012-02-14",
    description: "A powerful story about kindness, acceptance, and the importance of being yourself.",
  },
  {
    id: "5",
    title: "The Day the Crayons Quit",
    author: "Drew Daywalt",
    ageRange: "4-6",
    rating: 4.8,
    reviewCount: 11240,
    price: {
      amazon: "$7.99",
      barnesNoble: "$8.99",
    },
    image: "/placeholder.svg?height=400&width=300",
    amazonUrl: "https://amazon.com/Day-Crayons-Quit-Drew-Daywalt/dp/0399255370",
    barnesNobleUrl: "https://www.barnesandnoble.com/w/the-day-the-crayons-quit-drew-daywalt/1115915532",
    isbn: "9780399255373",
    publisher: "Philomel Books",
    publishDate: "2013-06-27",
    description: "A hilarious story told through letters from crayons who have had enough.",
  },
  {
    id: "6",
    title: "Goodnight Moon",
    author: "Margaret Wise Brown",
    ageRange: "0-3",
    rating: 4.8,
    reviewCount: 18750,
    price: {
      amazon: "$8.99",
      barnesNoble: "$9.99",
    },
    image: "/placeholder.svg?height=400&width=300",
    amazonUrl: "https://amazon.com/Goodnight-Moon-Margaret-Wise-Brown/dp/0064430170",
    barnesNobleUrl: "https://www.barnesandnoble.com/w/goodnight-moon-margaret-wise-brown/1100170351",
    isbn: "9780064430173",
    publisher: "HarperCollins",
    publishDate: "1991-09-03",
    description: "A beloved bedtime story that has soothed children to sleep for generations.",
  },
]

export function TopSellersCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [viewMode, setViewMode] = useState<"carousel" | "grid">("carousel")

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % Math.max(1, topSellerBooks.length - 2))
  }

  const prevSlide = () => {
    setCurrentIndex(
      (prevIndex) => (prevIndex - 1 + Math.max(1, topSellerBooks.length - 2)) % Math.max(1, topSellerBooks.length - 2),
    )
  }

  // Generate structured data for SEO
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "Top Selling Children's Books This Week",
    description: "The most popular children's books currently trending on Amazon and Barnes & Noble",
    itemListElement: topSellerBooks.map((book, index) => ({
      "@type": "Book",
      position: index + 1,
      name: book.title,
      author: {
        "@type": "Person",
        name: book.author,
      },
      isbn: book.isbn,
      publisher: book.publisher,
      datePublished: book.publishDate,
      description: book.description,
      aggregateRating: {
        "@type": "AggregateRating",
        ratingValue: book.rating,
        reviewCount: book.reviewCount,
        bestRating: 5,
        worstRating: 1,
      },
      audience: {
        "@type": "PeopleAudience",
        suggestedMinAge: book.ageRange.split("-")[0],
        suggestedMaxAge: book.ageRange.split("-")[1],
      },
      offers: [
        {
          "@type": "Offer",
          price: book.price.amazon.replace("$", ""),
          priceCurrency: "USD",
          seller: {
            "@type": "Organization",
            name: "Amazon",
          },
          url: book.amazonUrl,
        },
        {
          "@type": "Offer",
          price: book.price.barnesNoble.replace("$", ""),
          priceCurrency: "USD",
          seller: {
            "@type": "Organization",
            name: "Barnes & Noble",
          },
          url: book.barnesNobleUrl,
        },
      ],
    })),
  }

  return (
    <section className="py-16 bg-white">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      <div className="container px-4 md:px-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold font-display text-gray-900 mb-2">Top Sellers This Week</h2>
            <p className="text-lg text-gray-700">
              The most popular children's books trending now on Amazon and Barnes & Noble
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === "carousel" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("carousel")}
              className={viewMode === "carousel" ? "bg-warm-blue" : "bg-transparent"}
            >
              Carousel
            </Button>
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className={viewMode === "grid" ? "bg-warm-blue" : "bg-transparent"}
            >
              Grid
            </Button>
          </div>
        </div>

        {viewMode === "carousel" ? (
          <div className="relative">
            <div className="overflow-hidden">
              <div
                className="flex transition-transform duration-300 ease-in-out"
                style={{ transform: `translateX(-${currentIndex * (100 / 3)}%)` }}
              >
                {topSellerBooks.map((book) => (
                  <div key={book.id} className="w-full sm:w-1/2 lg:w-1/3 flex-shrink-0 px-3">
                    <BookCard book={book} />
                  </div>
                ))}
              </div>
            </div>

            <Button
              variant="outline"
              size="icon"
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-white shadow-lg hover:bg-gray-50"
              onClick={prevSlide}
              aria-label="Previous books"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="icon"
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-white shadow-lg hover:bg-gray-50"
              onClick={nextSlide}
              aria-label="Next books"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>

            <div className="flex justify-center mt-6 space-x-2">
              {Array.from({ length: Math.max(1, topSellerBooks.length - 2) }).map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentIndex ? "bg-warm-blue" : "bg-gray-300"
                  }`}
                  onClick={() => setCurrentIndex(index)}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {topSellerBooks.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}

function BookCard({ book }: { book: Book }) {
  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative aspect-[3/4] overflow-hidden bg-gray-100">
        <Image
          src={book.image || "/placeholder.svg"}
          alt={`Cover of "${book.title}" by ${book.author} - A children's book for ages ${book.ageRange}`}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        <Badge className="absolute top-3 left-3 bg-warm-yellow text-gray-900 font-semibold">
          #{topSellerBooks.findIndex((b) => b.id === book.id) + 1} Bestseller
        </Badge>
        <Badge variant="outline" className="absolute top-3 right-3 bg-white/90 text-gray-700 font-medium">
          Ages {book.ageRange}
        </Badge>
      </div>

      <CardContent className="p-5 space-y-4">
        <div className="space-y-2">
          <h3 className="font-bold text-lg leading-tight line-clamp-2 group-hover:text-warm-blue transition-colors">
            {book.title}
          </h3>
          <p className="text-gray-600 font-medium">by {book.author}</p>
          <p className="text-sm text-gray-500 line-clamp-2">{book.description}</p>
        </div>

        <div className="flex items-center space-x-2">
          <div className="flex items-center">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < Math.floor(book.rating) ? "fill-warm-yellow text-warm-yellow" : "text-gray-300"
                }`}
              />
            ))}
          </div>
          <span className="text-sm font-medium">{book.rating}</span>
          <span className="text-sm text-gray-500">({book.reviewCount.toLocaleString()} reviews)</span>
        </div>

        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-gray-700">Amazon:</span>
            <span className="font-bold text-warm-blue">{book.price.amazon}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-gray-700">Barnes & Noble:</span>
            <span className="font-bold text-warm-blue">{book.price.barnesNoble}</span>
          </div>
        </div>

        <div className="flex flex-col space-y-2 pt-2">
          <Button className="w-full bg-[#FF9900] hover:bg-[#FF9900]/90 text-white font-semibold" asChild>
            <Link href={book.amazonUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4 mr-2" />
              View on Amazon
            </Link>
          </Button>
          <Button
            variant="outline"
            className="w-full border-[#00674A] text-[#00674A] hover:bg-[#00674A] hover:text-white font-semibold bg-transparent"
            asChild
          >
            <Link href={book.barnesNobleUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-4 w-4 mr-2" />
              View on B&N
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
