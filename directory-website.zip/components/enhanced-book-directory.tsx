"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Star, Filter, ExternalLink, Info, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getBooks, type Book } from "@/lib/database"

type SortOption = "popularity" | "rating" | "newest" | "title"
type AgeGroup = "0-3" | "4-6" | "7-9" | "10-12"

export function EnhancedBookDirectory() {
  const [activeTab, setActiveTab] = useState<AgeGroup>("0-3")
  const [sortBy, setSortBy] = useState<SortOption>("popularity")
  const [books, setBooks] = useState<Book[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const ageGroupLabels = {
    "0-3": "Baby & Toddler",
    "4-6": "Preschool",
    "7-9": "Early Reader",
    "10-12": "Tween",
  }

  // Fetch books when tab or sort changes
  useEffect(() => {
    async function fetchBooks() {
      setLoading(true)
      setError(null)

      try {
        const fetchedBooks = await getBooks({
          ageGroup: activeTab,
          sortBy,
          limit: 20,
        })
        setBooks(fetchedBooks)
      } catch (err) {
        console.error("Error fetching books:", err)
        setError("Failed to load books. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchBooks()
  }, [activeTab, sortBy])

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: `Children's Books for Ages ${activeTab}`,
    description: `Curated collection of ${ageGroupLabels[activeTab].toLowerCase()} books including bedtime stories, STEM books, and award-winning titles`,
    itemListElement: books.map((book, index) => ({
      "@type": "Book",
      position: index + 1,
      name: book.title,
      author: {
        "@type": "Person",
        name: book.author,
      },
      description: book.description,
      aggregateRating: {
        "@type": "AggregateRating",
        ratingValue: book.rating,
        reviewCount: book.review_count,
      },
      audience: {
        "@type": "PeopleAudience",
        suggestedMinAge: book.age_group.split("-")[0],
        suggestedMaxAge: book.age_group.split("-")[1],
      },
    })),
  }

  return (
    <div className="container px-4 md:px-6">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      <div className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold font-display text-gray-900 mb-4">Children's Book Directory</h1>
        <p className="text-xl text-gray-700 max-w-3xl mx-auto">
          Discover the perfect books for every age group. From bedtime stories and STEM adventures to award-winning
          tales that inspire young minds.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as AgeGroup)} className="w-full">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
          <TabsList className="grid w-full lg:w-auto grid-cols-2 lg:grid-cols-4 h-auto p-1 bg-warm-cream">
            <TabsTrigger
              value="0-3"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Baby & Toddler</span>
              <span className="text-xs opacity-75">Ages 0–3</span>
            </TabsTrigger>
            <TabsTrigger
              value="4-6"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Preschool</span>
              <span className="text-xs opacity-75">Ages 4–6</span>
            </TabsTrigger>
            <TabsTrigger
              value="7-9"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Early Reader</span>
              <span className="text-xs opacity-75">Ages 7–9</span>
            </TabsTrigger>
            <TabsTrigger
              value="10-12"
              className="flex flex-col items-center p-4 data-[state=active]:bg-warm-blue data-[state=active]:text-white"
            >
              <span className="font-semibold">Tween</span>
              <span className="text-xs opacity-75">Ages 10–12</span>
            </TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">Sort by:</span>
            </div>
            <Select value={sortBy} onValueChange={(value) => setSortBy(value as SortOption)}>
              <SelectTrigger className="w-[180px] bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="title">Alphabetical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {["0-3", "4-6", "7-9", "10-12"].map((ageGroup) => (
          <TabsContent key={ageGroup} value={ageGroup} className="mt-0">
            <BookGrid
              books={activeTab === ageGroup ? books : []}
              ageGroup={ageGroupLabels[ageGroup as AgeGroup]}
              loading={activeTab === ageGroup ? loading : false}
              error={activeTab === ageGroup ? error : null}
            />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

function BookGrid({
  books,
  ageGroup,
  loading,
  error,
}: {
  books: Book[]
  ageGroup: string
  loading: boolean
  error: string | null
}) {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-warm-blue" />
        <span className="ml-2 text-gray-600">Loading books...</span>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500 text-lg mb-4">{error}</p>
        <Button onClick={() => window.location.reload()} className="bg-warm-blue hover:bg-warm-blue/90">
          Try Again
        </Button>
      </div>
    )
  }

  if (books.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">No books found for this category.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">
          {ageGroup} Books ({books.length})
        </h2>
        <p className="text-gray-600">
          Showing {books.length} book{books.length !== 1 ? "s" : ""}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {books.map((book) => (
          <DatabaseBookCard key={book.id} book={book} />
        ))}
      </div>
    </div>
  )
}

function DatabaseBookCard({ book }: { book: Book }) {
  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative aspect-[3/4] overflow-hidden bg-gray-100">
        <Image
          src={book.image_url || "/placeholder.svg?height=300&width=200"}
          alt={`Cover of "${book.title}" by ${book.author} - ${book.description?.split(".")[0] || "Children's book"}`}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />

        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {book.is_featured && <Badge className="bg-warm-yellow text-gray-900 font-semibold">Featured</Badge>}
          {book.awards.length > 0 && <Badge className="bg-purple-500 text-white font-semibold">Award Winner</Badge>}
        </div>

        <Badge variant="outline" className="absolute top-3 right-3 bg-white/90 text-gray-700 font-medium">
          Ages {book.age_group}
        </Badge>
      </div>

      <CardContent className="p-5 space-y-4">
        <div className="space-y-2">
          <h3 className="font-bold text-lg leading-tight line-clamp-2 group-hover:text-warm-blue transition-colors">
            {book.title}
          </h3>
          <p className="text-gray-600 font-medium">by {book.author}</p>

          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(book.rating) ? "fill-warm-yellow text-warm-yellow" : "text-gray-300"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm font-medium">{book.rating}</span>
            <span className="text-sm text-gray-500">({book.review_count.toLocaleString()})</span>
          </div>
        </div>

        {book.description && <p className="text-sm text-gray-700 line-clamp-3 leading-relaxed">{book.description}</p>}

        <div className="flex flex-wrap gap-1">
          {book.categories.slice(0, 2).map((cat) => (
            <Badge key={cat} variant="outline" className="text-xs bg-warm-cream text-gray-700">
              {cat}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between pt-2">
          {book.price && <span className="text-lg font-bold text-warm-blue">${book.price}</span>}
          {book.awards.length > 0 && (
            <span className="text-xs text-gray-500">
              {book.awards.length} award{book.awards.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>

        <div className="flex flex-col space-y-2 pt-2">
          {book.amazon_url && (
            <Button className="w-full bg-warm-blue hover:bg-warm-blue/90 text-white font-semibold" asChild>
              <Link href={book.amazon_url} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" />
                Buy Now
              </Link>
            </Button>
          )}
          <Button
            variant="outline"
            className="w-full border-warm-blue text-warm-blue hover:bg-warm-blue hover:text-white font-semibold bg-transparent"
            asChild
          >
            <Link href={`/books/${book.id}`}>
              <Info className="h-4 w-4 mr-2" />
              More Info
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
