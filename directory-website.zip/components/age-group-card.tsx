import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"

interface AgeGroupCardProps {
  ageRange: string
  title: string
  description: string
  bookCount: number
  color: string
  href: string
}

export function AgeGroupCard({ ageRange, title, description, bookCount, color, href }: AgeGroupCardProps) {
  return (
    <Link href={href}>
      <Card className="group overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
        <div className={`${color} p-6 text-white relative overflow-hidden`}>
          <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="relative z-10">
            <div className="text-3xl font-bold font-display mb-2">{ageRange}</div>
            <div className="text-lg font-semibold mb-1">{title}</div>
            <div className="text-sm opacity-90">{bookCount.toLocaleString()} books</div>
          </div>
        </div>

        <CardContent className="p-6">
          <p className="text-gray-600 mb-4 leading-relaxed">{description}</p>
          <div className="flex items-center text-warm-blue font-semibold group-hover:text-warm-blue/80 transition-colors">
            <span>Explore Books</span>
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
