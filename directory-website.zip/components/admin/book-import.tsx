"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertCircle, Download, Plus, X } from "lucide-react"
import { bulkImportBooks } from "@/lib/book-apis"
import type { Book } from "@/lib/supabase"

export function BookImport() {
  const [source, setSource] = useState<"amazon" | "barnes-noble">("amazon")
  const [ageGroup, setAgeGroup] = useState("")
  const [queries, setQueries] = useState<string[]>([])
  const [newQuery, setNewQuery] = useState("")
  const [importing, setImporting] = useState(false)
  const [progress, setProgress] = useState(0)
  const [importedBooks, setImportedBooks] = useState<Book[]>([])
  const [error, setError] = useState("")

  const addQuery = () => {
    if (newQuery.trim() && !queries.includes(newQuery.trim())) {
      setQueries([...queries, newQuery.trim()])
      setNewQuery("")
    }
  }

  const removeQuery = (query: string) => {
    setQueries(queries.filter((q) => q !== query))
  }

  const handleImport = async () => {
    if (queries.length === 0) {
      setError("Please add at least one search query")
      return
    }

    setImporting(true)
    setError("")
    setProgress(0)
    setImportedBooks([])

    try {
      const books = await bulkImportBooks(source, queries, ageGroup)
      setImportedBooks(books)
      setProgress(100)
    } catch (err) {
      setError("Failed to import books. Please try again.")
      console.error("Import error:", err)
    } finally {
      setImporting(false)
    }
  }

  const popularQueries = {
    "0-3": ["board books", "baby books", "toddler books", "bedtime stories", "first words"],
    "4-6": ["picture books", "preschool books", "alphabet books", "counting books", "fairy tales"],
    "7-9": ["early readers", "chapter books", "beginning chapter books", "easy readers", "first chapter books"],
    "10-12": ["middle grade", "tween books", "adventure books", "mystery books", "fantasy books"],
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Download className="h-5 w-5 mr-2" />
            Bulk Import Books
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Source Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Import Source</Label>
              <Select value={source} onValueChange={(value: "amazon" | "barnes-noble") => setSource(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="amazon">Amazon</SelectItem>
                  <SelectItem value="barnes-noble">Barnes & Noble</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Age Group (Optional)</Label>
              <Select value={ageGroup || "all"} onValueChange={setAgeGroup}>
                <SelectTrigger>
                  <SelectValue placeholder="All ages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All ages</SelectItem>
                  <SelectItem value="0-3">Baby & Toddler (0-3)</SelectItem>
                  <SelectItem value="4-6">Preschool (4-6)</SelectItem>
                  <SelectItem value="7-9">Early Reader (7-9)</SelectItem>
                  <SelectItem value="10-12">Tween (10-12)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Search Queries */}
          <div>
            <Label>Search Queries</Label>
            <div className="flex gap-2 mb-2">
              <Input
                placeholder="Enter search term (e.g., 'dinosaur books')"
                value={newQuery}
                onChange={(e) => setNewQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && addQuery()}
              />
              <Button onClick={addQuery} disabled={!newQuery.trim()}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {/* Current Queries */}
            <div className="flex flex-wrap gap-2 mb-4">
              {queries.map((query) => (
                <Badge key={query} variant="outline" className="bg-warm-cream">
                  {query}
                  <button onClick={() => removeQuery(query)} className="ml-1 hover:text-red-600">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>

            {/* Popular Queries */}
            {ageGroup && popularQueries[ageGroup as keyof typeof popularQueries] && (
              <div>
                <Label className="text-sm text-gray-600">Popular queries for {ageGroup}:</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {popularQueries[ageGroup as keyof typeof popularQueries].map((query) => (
                    <Button
                      key={query}
                      variant="outline"
                      size="sm"
                      onClick={() => !queries.includes(query) && setQueries([...queries, query])}
                      disabled={queries.includes(query)}
                      className="text-xs bg-transparent"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      {query}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Error Display */}
          {error && (
            <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="h-4 w-4 text-red-500 mr-2" />
              <span className="text-red-700">{error}</span>
            </div>
          )}

          {/* Import Progress */}
          {importing && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Importing books...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          )}

          {/* Import Button */}
          <Button
            onClick={handleImport}
            disabled={importing || queries.length === 0}
            className="w-full bg-warm-blue hover:bg-warm-blue/90"
          >
            {importing ? "Importing..." : `Import Books from ${source === "amazon" ? "Amazon" : "Barnes & Noble"}`}
          </Button>

          {/* Results */}
          {importedBooks.length > 0 && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-3">Successfully imported {importedBooks.length} books</h3>
              <div className="grid gap-2 max-h-60 overflow-y-auto">
                {importedBooks.map((book) => (
                  <div key={book.id} className="flex items-center p-2 bg-green-50 border border-green-200 rounded">
                    <div className="flex-1">
                      <p className="font-medium">{book.title}</p>
                      <p className="text-sm text-gray-600">by {book.author}</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Imported</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
