"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Upload, X, Plus } from "lucide-react"

const ageGroups = [
  { value: "0-3", label: "Baby & Toddler (0-3)" },
  { value: "4-6", label: "Preschool (4-6)" },
  { value: "7-9", label: "Early Reader (7-9)" },
  { value: "10-12", label: "Tween (10-12)" },
]

const commonCategories = [
  "picture book",
  "chapter book",
  "graphic novel",
  "STEM",
  "bedtime",
  "humor",
  "adventure",
  "friendship",
  "classic",
  "educational",
  "fantasy",
  "mystery",
  "realistic fiction",
  "biography",
  "poetry",
  "fairy tale",
]

export function BookForm({ book = null }: { book?: any }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [imagePreview, setImagePreview] = useState(book?.image_url || "")

  const [formData, setFormData] = useState({
    title: book?.title || "",
    author: book?.author || "",
    isbn: book?.isbn || "",
    age_group: book?.age_group || "",
    description: book?.description || "",
    price: book?.price || "",
    publisher: book?.publisher || "",
    publish_date: book?.publish_date || "",
    page_count: book?.page_count || "",
    categories: book?.categories || [],
    awards: book?.awards || [],
    amazon_url: book?.amazon_url || "",
    barnes_noble_url: book?.barnes_noble_url || "",
    is_featured: book?.is_featured || false,
    status: book?.status || "draft",
  })

  const [newCategory, setNewCategory] = useState("")
  const [newAward, setNewAward] = useState("")

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const addCategory = (category: string) => {
    if (category && !formData.categories.includes(category)) {
      handleInputChange("categories", [...formData.categories, category])
    }
    setNewCategory("")
  }

  const removeCategory = (category: string) => {
    handleInputChange(
      "categories",
      formData.categories.filter((c) => c !== category),
    )
  }

  const addAward = () => {
    if (newAward && !formData.awards.includes(newAward)) {
      handleInputChange("awards", [...formData.awards, newAward])
    }
    setNewAward("")
  }

  const removeAward = (award: string) => {
    handleInputChange(
      "awards",
      formData.awards.filter((a) => a !== award),
    )
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Here you would typically send the data to your API
      console.log("Submitting book data:", formData)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Redirect back to books list
      router.push("/admin/books")
    } catch (error) {
      console.error("Error saving book:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{book ? "Edit Book" : "Add New Book"}</h1>
          <p className="text-gray-600">{book ? "Update book information" : "Add a new book to the database"}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Information */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Title *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => handleInputChange("title", e.target.value)}
                      placeholder="Enter book title"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="author">Author *</Label>
                    <Input
                      id="author"
                      value={formData.author}
                      onChange={(e) => handleInputChange("author", e.target.value)}
                      placeholder="Enter author name"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    placeholder="Enter book description"
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="isbn">ISBN</Label>
                    <Input
                      id="isbn"
                      value={formData.isbn}
                      onChange={(e) => handleInputChange("isbn", e.target.value)}
                      placeholder="978-0-123456-78-9"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Price ($)</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => handleInputChange("price", Number.parseFloat(e.target.value))}
                      placeholder="9.99"
                    />
                  </div>
                  <div>
                    <Label htmlFor="page_count">Page Count</Label>
                    <Input
                      id="page_count"
                      type="number"
                      value={formData.page_count}
                      onChange={(e) => handleInputChange("page_count", Number.parseInt(e.target.value))}
                      placeholder="32"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="publisher">Publisher</Label>
                    <Input
                      id="publisher"
                      value={formData.publisher}
                      onChange={(e) => handleInputChange("publisher", e.target.value)}
                      placeholder="Publisher name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="publish_date">Publish Date</Label>
                    <Input
                      id="publish_date"
                      type="date"
                      value={formData.publish_date}
                      onChange={(e) => handleInputChange("publish_date", e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Categories & Awards</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Age Group *</Label>
                  <Select value={formData.age_group} onValueChange={(value) => handleInputChange("age_group", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select age group" />
                    </SelectTrigger>
                    <SelectContent>
                      {ageGroups.map((group) => (
                        <SelectItem key={group.value} value={group.value}>
                          {group.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Categories</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {formData.categories.map((category) => (
                      <Badge key={category} variant="outline" className="bg-warm-cream">
                        {category}
                        <button
                          type="button"
                          onClick={() => removeCategory(category)}
                          className="ml-1 hover:text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {commonCategories
                      .filter((cat) => !formData.categories.includes(cat))
                      .map((category) => (
                        <Button
                          key={category}
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => addCategory(category)}
                          className="text-xs bg-transparent"
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          {category}
                        </Button>
                      ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add custom category"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addCategory(newCategory))}
                    />
                    <Button type="button" onClick={() => addCategory(newCategory)}>
                      Add
                    </Button>
                  </div>
                </div>

                <div>
                  <Label>Awards</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {formData.awards.map((award) => (
                      <Badge key={award} variant="outline" className="bg-yellow-50">
                        {award}
                        <button type="button" onClick={() => removeAward(award)} className="ml-1 hover:text-red-600">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add award"
                      value={newAward}
                      onChange={(e) => setNewAward(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addAward())}
                    />
                    <Button type="button" onClick={addAward}>
                      Add
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>External Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="amazon_url">Amazon URL</Label>
                  <Input
                    id="amazon_url"
                    value={formData.amazon_url}
                    onChange={(e) => handleInputChange("amazon_url", e.target.value)}
                    placeholder="https://amazon.com/..."
                  />
                </div>
                <div>
                  <Label htmlFor="barnes_noble_url">Barnes & Noble URL</Label>
                  <Input
                    id="barnes_noble_url"
                    value={formData.barnes_noble_url}
                    onChange={(e) => handleInputChange("barnes_noble_url", e.target.value)}
                    placeholder="https://barnesandnoble.com/..."
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Book Cover</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {imagePreview ? (
                    <div className="relative">
                      <Image
                        src={imagePreview || "/placeholder.svg"}
                        alt="Book cover preview"
                        width={200}
                        height={250}
                        className="rounded-lg object-cover mx-auto"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setImagePreview("")}
                        className="absolute top-2 right-2 bg-white"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">Upload book cover</p>
                    </div>
                  )}
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-warm-blue file:text-white hover:file:bg-warm-blue/90"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Publishing Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Status</Label>
                  <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="published">Published</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="is_featured"
                    checked={formData.is_featured}
                    onCheckedChange={(checked) => handleInputChange("is_featured", checked)}
                  />
                  <Label htmlFor="is_featured">Featured Book</Label>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col space-y-2">
              <Button type="submit" disabled={loading} className="bg-warm-blue hover:bg-warm-blue/90">
                {loading ? "Saving..." : book ? "Update Book" : "Add Book"}
              </Button>
              <Button type="button" variant="outline" onClick={() => router.back()} className="bg-transparent">
                Cancel
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}
