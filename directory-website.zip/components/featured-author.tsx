import Image from "next/image"
import Link from "next/link"
import { ExternalLink, Award } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export function FeaturedAuthor() {
  return (
    <section className="py-16 bg-gradient-to-r from-warm-cream to-warm-peach/30">
      <div className="container px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <Badge className="bg-warm-yellow text-gray-900 font-semibold mb-4">
              <Award className="h-4 w-4 mr-1" />
              Featured Author
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold font-display text-gray-900">Meet Mo Willems</h2>
            <p className="text-lg text-gray-700 mt-2">
              Award-winning author and illustrator of beloved children's books
            </p>
          </div>

          <Card className="overflow-hidden shadow-xl">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="relative aspect-square lg:aspect-auto">
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Portrait of Mo Willems, children's book author"
                  fill
                  className="object-cover"
                />
              </div>

              <CardContent className="p-8 flex flex-col justify-center">
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold font-display text-gray-900">Three-time Caldecott Honor winner</h3>
                  <p className="text-gray-700 leading-relaxed">
                    Mo Willems is the creator of the beloved Elephant and Piggie series, the Pigeon books, and many
                    other award-winning children's books. His work has been translated into over 20 languages and has
                    won numerous awards including three Caldecott Honors.
                  </p>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-gray-900">Popular Books:</h4>
                    <ul className="text-sm text-gray-700 space-y-1">
                      <li>• Don't Let the Pigeon Drive the Bus!</li>
                      <li>• There Is a Bird on Your Head!</li>
                      <li>• We Are in a Book!</li>
                      <li>• The Duckling Gets a Cookie!?</li>
                    </ul>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    <Button className="bg-warm-blue hover:bg-warm-blue/90" asChild>
                      <Link href="/authors/mo-willems">View All Books</Link>
                    </Button>
                    <Button
                      variant="outline"
                      className="border-warm-blue text-warm-blue hover:bg-warm-blue hover:text-white bg-transparent"
                      asChild
                    >
                      <Link href="/authors/mo-willems/interview">
                        Read Interview
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </div>
          </Card>

          {/* Embedded Book Preview */}
          <div className="mt-8">
            <h3 className="text-xl font-bold font-display text-gray-900 mb-4 text-center">
              Preview: "Don't Let the Pigeon Drive the Bus!"
            </h3>
            <Card className="overflow-hidden">
              <div className="aspect-video bg-gray-100 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <div className="w-16 h-16 mx-auto mb-4 bg-warm-blue/20 rounded-full flex items-center justify-center">
                    <ExternalLink className="h-8 w-8 text-warm-blue" />
                  </div>
                  <p className="text-sm">Interactive book preview would be embedded here</p>
                  <p className="text-xs mt-1">Click to read the first few pages</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
