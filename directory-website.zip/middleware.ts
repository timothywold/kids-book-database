import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  // Check if this is an admin route
  if (req.nextUrl.pathname.startsWith("/admin")) {
    // Skip login page
    if (req.nextUrl.pathname === "/admin/login") {
      return res
    }

    // Get session
    const {
      data: { session },
    } = await supabase.auth.getSession()

    // No session - redirect to login
    if (!session) {
      return NextResponse.redirect(new URL("/admin/login", req.url))
    }

    // Check if user is admin
    const isAdmin =
      session.user.email === "wold.tim2@gmail.com" ||
      session.user.email?.endsWith("@admin.com") ||
      session.user.user_metadata?.role === "admin"

    // Not admin - redirect to home
    if (!isAdmin) {
      return NextResponse.redirect(new URL("/", req.url))
    }
  }

  return res
}

export const config = {
  matcher: ["/admin/:path*"],
}
